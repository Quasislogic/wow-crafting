-- PsyQuiz_Skeleton.lua — example of reusing PsyLobby for a quiz
-- Slash: /psyquiz [maxPlayers]
-- Players join with: !join

local qf = CreateFrame("Frame")
SLASH_PSYQUIZ1 = "/psyquiz"

local function normalizedRealm() local rn=GetNormalizedRealmName(); if rn and rn~="" then return rn:gsub("%s+","") end local r=GetRealmName() or "UnknownRealm"; return r:gsub("%s+","") end
local function myFull() return (UnitName("player") or "Player").."-"..normalizedRealm() end
local function short(full) return (full and full:match("^[^-]+")) or (full or "?") end
local function say(m) SendChatMessage(m,"SAY") end
local function emote(m) SendChatMessage(m,"EMOTE") end

local QUIZ = { lobby=nil, players={} }

local function startQuiz()
  -- You’d replace this with your actual quiz flow
  emote("📚 Quiz starting! (skeleton) — ask your first question here.")
end

SlashCmdList.PSYQUIZ = function(msg)
  local mp = tonumber(msg:match("^(%d+)")) or 5
  if QUIZ.lobby and QUIZ.lobby.active then emote("A quiz lobby is already running."); return end

  QUIZ.lobby = PsyLobby.Start({
    host = myFull(),
    solo = false,
    maxPlayers = math.max(2, math.min(mp, 40)),
    duration = 30,
    warnAt = 10,
    sayFn = say,
    emoteFn = emote,
    joinMatcher = function(message)
      local m = (message or ""):lower():gsub("%s+"," ")
      return m == "!join"
    end,
    canJoin = function() return true end,
    onJoin = function(lobby, full) end,
    onWarn = function(lobby)
      emote("⏳ Quiz lobby closing in 10s.")
      emote("Waiting: " .. lobby:PlayersListString())
    end,
    onClose = function(lobby)
      if #lobby.players < 2 then emote("Not enough players for the quiz."); return end
      wipe(QUIZ.players); for i,full in ipairs(lobby.players) do QUIZ.players[i]=full end
      emote("Quiz lobby closed. Players: " .. lobby:PlayersListString())
      startQuiz()
    end,
    onCancel = function(_, why) emote("Quiz lobby cancelled.") end,
  })

  say(("Quiz lobby started by %s — type !join (max %d)."):format(short(myFull()), mp))
  say("Waiting: —")
  say("Lobby will close in 30 seconds or when full.")
end

-- Forward chat to lobby
qf:RegisterEvent("CHAT_MSG_SAY"); qf:RegisterEvent("CHAT_MSG_PARTY"); qf:RegisterEvent("CHAT_MSG_RAID")
qf:RegisterEvent("CHAT_MSG_INSTANCE_CHAT")
qf:SetScript("OnEvent", function(_, ev, msg, author)
  if QUIZ.lobby and QUIZ.lobby.active then
    local aName, aRealm = strsplit("-", author or ""); if not aRealm or aRealm=="" then author=(aName or "?").."-"..normalizedRealm() end
    QUIZ.lobby:OnChat(msg or "", author)
  end
end)
