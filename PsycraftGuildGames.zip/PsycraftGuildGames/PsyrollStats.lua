-- PsyRollStats.lua — totals + nemesis/victim + gold drain/source + chat trigger
-- SavedVariables: PsyRollStatsDB
-- Chat trigger: "!psyroll stats [Name]" → replies via runtime fallback (Instance→Raid→Party→Emote)
-- Solo games do NOT count.

_G.PsyRollStatsDB = _G.PsyRollStatsDB or {
  current = nil,  -- { id, players = {full...}, stake }
  nextID = 1,
  agg = {},       -- [ "Name-Realm" ] = totals + head-to-head
}
local DB = _G.PsyRollStatsDB

-- helpers
local function normalizedRealm()
  local rn=GetNormalizedRealmName()
  if rn and rn~="" then return rn:gsub("%s+","") end
  local r=GetRealmName() or "UnknownRealm"; return r:gsub("%s+","")
end
local function myFull() return (UnitName("player") or "Player").."-"..normalizedRealm() end
local function short(full) return (full and full:match("^[^-]+")) or (full or "?") end
local function splitFull(full) local n,r=(full or "?"):match("^([^-]+)%-(.+)$"); if not n then n,r=(full or "?"),"UnknownRealm" end; return n,r end
local function formatGold(n) return string.format("%dg", n or 0) end

-- runtime fallback sender (Instance→Raid→Party→Emote)
local function sendRuntime(msg)
  if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE) then SendChatMessage(msg,"INSTANCE_CHAT"); return end
  if IsInRaid() then SendChatMessage(msg,"RAID"); return end
  if IsInGroup() then SendChatMessage(msg,"PARTY"); return end
  SendChatMessage(msg,"EMOTE")
end

-- aggregates
local function ensureAgg(full)
  local A = DB.agg[full]
  if not A then
    A = {
      totalWins=0,totalLosses=0,friendlyWins=0,friendlyLosses=0,stakedWins=0,stakedLosses=0,
      goldWon=0,goldLost=0, vs={},
    }
    DB.agg[full]=A
  else
    A.vs = A.vs or {}
  end
  return A
end
local function ensureVs(A, opp) local v=A.vs[opp]; if not v then v={w=0,l=0,gwon=0,glost=0}; A.vs[opp]=v end; return v end

local function resolveFull(input)
  if not input or input=="" then return myFull() end
  if input:find("-",1,true) then return input end
  local candidate = input.."-"..normalizedRealm()
  if DB.agg[candidate] then return candidate end
  for full,_ in pairs(DB.agg) do if short(full):lower()==input:lower() then return full end end
  return candidate
end

local function summaries(full)
  local A=DB.agg[full]; if not A then return end
  local nemF,nemL, vicF,vicW, drainF,drainAmt, sourceF,sourceNet
  nemL, vicW, drainAmt, sourceNet = 0,0,0,0
  for opp,rec in pairs(A.vs) do
    local w,l = rec.w or 0, rec.l or 0
    local gw,gl = rec.gwon or 0, rec.glost or 0
    local gnet = gw - gl
    if l>nemL then nemL=l; nemF=opp end
    if w>vicW then vicW=w; vicF=opp end
    if gl>drainAmt then drainAmt=gl; drainF=opp end
    if gnet>sourceNet then sourceNet=gnet; sourceF=opp end
  end
  return nemF,nemL, vicF,vicW, drainF,drainAmt, sourceF,sourceNet
end

-- API for PsyRoll
function _G.PsyRoll_Stats_BeginGame(players, stakeGold)
  local id=DB.nextID or 1; DB.nextID=id+1
  local snapshot={}; for i,full in ipairs(players or {}) do snapshot[i]=full end
  DB.current = { id=id, players=snapshot, stake=tonumber(stakeGold) or 0 }
end

function _G.PsyRoll_Stats_EndGame(winnerFull)
  local cur=DB.current; if not cur then return end
  if #cur.players <= 1 then DB.current=nil; return end -- solo: do not count
  local stake=cur.stake or 0; local staked = stake>0; local n=#cur.players; local pot=((n>0) and (n-1)*stake) or 0

  for _,full in ipairs(cur.players) do
    local A=ensureAgg(full)
    if full==winnerFull then
      A.totalWins = A.totalWins + 1
      if staked then A.stakedWins = A.stakedWins + 1 else A.friendlyWins = A.friendlyWins + 1 end
      A.goldWon = A.goldWon + pot
    else
      A.totalLosses = A.totalLosses + 1
      if staked then A.stakedLosses = A.stakedLosses + 1 else A.friendlyLosses = A.friendlyLosses + 1 end
      A.goldLost = A.goldLost + stake
    end
  end

  if staked and stake>0 then
    for _,loser in ipairs(cur.players) do
      if loser~=winnerFull then
        local Aw=ensureAgg(winnerFull); local vsW=ensureVs(Aw, loser); vsW.w=(vsW.w or 0)+1; vsW.gwon=(vsW.gwon or 0)+stake
        local Al=ensureAgg(loser);      local vsL=ensureVs(Al, winnerFull); vsL.l=(vsL.l or 0)+1; vsL.glost=(vsL.glost or 0)+stake
      end
    end
  else
    for _,loser in ipairs(cur.players) do
      if loser~=winnerFull then
        local Aw=ensureAgg(winnerFull); ensureVs(Aw, loser).w = (ensureVs(Aw, loser).w or 0) + 1
        local Al=ensureAgg(loser);      ensureVs(Al, winnerFull).l = (ensureVs(Al, winnerFull).l or 0) + 1
      end
    end
  end

  DB.current=nil
end

function _G.PsyRoll_Stats_GetSummary(input)
  local full=resolveFull(input); local A=DB.agg[full]; local n,r=splitFull(full)
  if not A then
    return {name=n,realm=r,totalWins=0,totalLosses=0,friendlyWins=0,friendlyLosses=0,
      stakedWins=0,stakedLosses=0,goldWon=0,goldLost=0,netGold=0,
      nemesis=nil,nemesisCount=0,victim=nil,victimCount=0,goldDrain=nil,goldDrainAmt=0,goldSource=nil,goldSourceNet=0}
  end
  local nemF,nemL, vicF,vicW, drainF,drainAmt, sourceF,sourceNet = summaries(full)
  return {
    name=n,realm=r,
    totalWins=A.totalWins or 0, totalLosses=A.totalLosses or 0,
    friendlyWins=A.friendlyWins or 0, friendlyLosses=A.friendlyLosses or 0,
    stakedWins=A.stakedWins or 0, stakedLosses=A.stakedLosses or 0,
    goldWon=A.goldWon or 0, goldLost=A.goldLost or 0, netGold=(A.goldWon or 0)-(A.goldLost or 0),
    nemesis=nemF and short(nemF) or nil, nemesisCount=nemL or 0,
    victim=vicF and short(vicF) or nil,  victimCount=vicW or 0,
    goldDrain=drainF and short(drainF) or nil, goldDrainAmt=drainAmt or 0,
    goldSource=sourceF and short(sourceF) or nil, goldSourceNet=sourceNet or 0,
  }
end

function _G.PsyRoll_Stats_ResetAll() DB.agg = {}; return true end
function _G.PsyRoll_Stats_ResetPlayer(input) local full=resolveFull(input); DB.agg[full]=nil; return full end

-- Chat trigger: "!psyroll stats [Name]"
local function handleStatsRequest(msg, author)
  local m=(msg or ""):lower():gsub("%s+"," "):gsub("^%s+",""):gsub("%s+$","")
  local body=m:match("^!psyroll%s+stats%s*(.*)$"); if not body then return end
  local targetInput=(body and body~="") and body or (author and author:match("^[^-]+"))
  local s=_G.PsyRoll_Stats_GetSummary(targetInput)
  sendRuntime(string.format("PsyRoll — %s-%s: W:%d L:%d (Friendly %d/%d, Staked %d/%d)",
    s.name,s.realm,s.totalWins,s.totalLosses,s.friendlyWins,s.friendlyLosses,s.stakedWins,s.stakedLosses))
  sendRuntime(string.format("Gold — Won %s, Lost %s, Net %s",
    formatGold(s.goldWon), formatGold(s.goldLost), formatGold(s.netGold)))
  sendRuntime(string.format("Nemesis: %s • Victim: %s",
    s.nemesis and (s.nemesis.." ("..s.nemesisCount..")") or "—",
    s.victim  and (s.victim.." ("..s.victimCount..")")   or "—"))
  sendRuntime(string.format("Gold drain: %s • Gold source: %s",
    s.goldDrain and (s.goldDrain.." ("..formatGold(s.goldDrainAmt)..")") or "—",
    (s.goldSource and s.goldSourceNet and s.goldSourceNet>0)
      and (s.goldSource.." (+"..formatGold(s.goldSourceNet)..")") or "—"))
end

-- Listen on say/party/raid/instance/whisper (never guild)
local sf=CreateFrame("Frame")
local EVTS={"CHAT_MSG_SAY","CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER","CHAT_MSG_RAID","CHAT_MSG_RAID_LEADER",
            "CHAT_MSG_INSTANCE_CHAT","CHAT_MSG_INSTANCE_CHAT_LEADER","CHAT_MSG_WHISPER"}
for _,ev in ipairs(EVTS) do sf:RegisterEvent(ev) end
sf:SetScript("OnEvent", function(_, event, ...) local msg, author = ...; handleStatsRequest(msg or "", author or "") end)
