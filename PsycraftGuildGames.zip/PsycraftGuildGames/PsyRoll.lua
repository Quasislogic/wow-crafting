-- PsyRoll.lua — game logic built on PsyLobby (Managed)
-- Requires: PsyLobby.lua exporting _G.PsyLobby (Managed mode available)
-- Optional: PsyRollStats.lua for begin/end hooks
-- No SavedVariables used here.

local ADDON = "PsyRoll"
local f = CreateFrame("Frame")

------------------------------------------------------------
-- Utils
------------------------------------------------------------
local function trim(s) return (s or ""):gsub("^%s+",""):gsub("%s+$","") end
local function splitWords(s) local t={}; for w in (s or ""):gmatch("%S+") do t[#t+1]=w end; return t end
local function short(full) return (full and full:match("^[^-]+")) or (full or "?") end

local function normalizedRealm()
  local r = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "UnknownRealm"
  return (r or "UnknownRealm"):gsub("%s+","")
end

local function playerFull()
  local n = (UnitName and UnitName("player")) or "Player"
  return n .. "-" .. normalizedRealm()
end

local function formatGold(g) return string.format("%dg", g or 0) end
local function printLocal(msg) print(string.format("|cff00ff88[%s]|r %s", ADDON, msg)) end

-- Timer helper (Classic/MoP friendly)
local function NewTimer(delay, fn)
  if C_Timer and C_Timer.NewTimer then return C_Timer.NewTimer(delay, fn) end
  local t = { _cancelled=false }
  function t:Cancel() self._cancelled=true end
  C_Timer.After(delay, function() if not t._cancelled then fn() end end)
  return t
end

------------------------------------------------------------
-- Chat routing
-- Start-time blurbs: user-chosen channel (AUTO/SAY/PARTY/RAID/INSTANCE/WHISPER/EMOTE)
-- Runtime: INSTANCE → RAID → PARTY → EMOTE (never SAY/GUILD)
------------------------------------------------------------
local GPref = { startChan = "AUTO", whisperTo = nil }
local Last  = { chan="SAY", whisperTo=nil } -- remembered “AUTO” fallbacks

local function channelUsable(ch)
  if ch == "INSTANCE_CHAT" then
    return IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE)
  elseif ch == "RAID" then
    return IsInRaid()
  elseif ch == "PARTY" then
    return IsInGroup()
  elseif ch == "GUILD" then
    return false
  end
  return true
end

local function sendStart(msg)
  local ch = GPref.startChan or "AUTO"

  if ch == "AUTO" then
    -- Prefer context, not "last used"
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE) then
      ch = "INSTANCE_CHAT"
    elseif IsInRaid() then
      ch = "RAID"
    elseif IsInGroup() then
      ch = "PARTY"
    else
      ch = "SAY"  -- or "EMOTE" if you prefer
    end
  elseif ch == "WHISPER" then
    local target = GPref.whisperTo or Last.whisperTo
    if target and target ~= "" then SendChatMessage(msg, "WHISPER", nil, target); return end
    ch = "SAY"
  end

  if ch ~= "EMOTE" and ch ~= "WHISPER" then
    -- sanity check: if chosen channel isn't usable, fall back
    local function usable(c)
      if c == "INSTANCE_CHAT" then
        return IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE)
      elseif c == "RAID" then return IsInRaid()
      elseif c == "PARTY" then return IsInGroup()
      elseif c == "GUILD" then return false end
      return true
    end
    if not usable(ch) then ch = "SAY" end
  end

  SendChatMessage(msg, ch)
end


local function sendRuntime(msg)
  if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE) then
    SendChatMessage(msg, "INSTANCE_CHAT"); return
  end
  if IsInRaid() then SendChatMessage(msg, "RAID"); return end
  if IsInGroup() then SendChatMessage(msg, "PARTY"); return end
  SendChatMessage(msg, "EMOTE")
end

-- Track last spoken channel (for AUTO)
local function updateLastChannel(event, ...)
  if event == "CHAT_MSG_WHISPER_INFORM" then
    local _, target = ...
    Last.chan = "WHISPER"; Last.whisperTo = target
    return
  end
  local _, author = ...
  local aName = (author or ""):match("^[^-]+") or (author or "")
  if aName ~= UnitName("player") then return end
  if event:find("SAY") then Last.chan = "SAY"
  elseif event:find("PARTY") then Last.chan = "PARTY"
  elseif event:find("RAID") and not event:find("INSTANCE") then Last.chan = "RAID"
  elseif event:find("INSTANCE_CHAT") then Last.chan = "INSTANCE_CHAT"
  end
end

------------------------------------------------------------
-- Game state
------------------------------------------------------------
local G = {
  active=false, phase="idle", host=nil,
  maxPlayers=5, startMax=1000, stakeGold=0,
  players={}, joined={}, byShort={}, -- filled when lobby closes
  seedRolls={}, currentMax=nil, turn=1, rollCount={}, turnTimer=nil,
  lobby=nil,
}

local function resetTimers()
  if G.turnTimer then G.turnTimer:Cancel() end
  G.turnTimer = nil
end

local function resetAll()
  resetTimers()
  G.active=false; G.phase="idle"; G.host=nil
  G.maxPlayers=5; G.startMax=1000; G.stakeGold=0
  wipe(G.players); wipe(G.joined); wipe(G.byShort); wipe(G.seedRolls); wipe(G.rollCount)
  G.currentMax=nil; G.turn=1
  if G.lobby and G.lobby.active then G.lobby:Stop("reset") end
  G.lobby=nil
end

local function playersListString()
  local n={} for i,full in ipairs(G.players) do n[i]=short(full) end
  return (#n>0) and table.concat(n, ", ") or "—"
end

------------------------------------------------------------
-- Turn helpers
------------------------------------------------------------
local function setTurnTimer()
  if G.turnTimer then G.turnTimer:Cancel() end
  G.turnTimer = NewTimer(40, function()
    if not (G.active and G.phase=="playing") then return end
    local p = G.players[G.turn]
    sendRuntime(string.format("%s is taking too long. Type /psyroll skip to advance.", short(p)))
  end)
end

local function announceCurrentTurn()
  local p = G.players[G.turn]
  sendRuntime(string.format("It's %s's turn — /roll 1-%d", short(p), G.currentMax))
  setTurnTimer()
end

local function beginPlaying()
  G.phase = "playing"
  G.currentMax = G.startMax
  G.turn = 1

  -- Stats begin (safe if module not loaded)
  if type(_G.PsyRoll_Stats_BeginGame) == "function" then
    _G.PsyRoll_Stats_BeginGame(G.players, G.stakeGold or 0)
  end

  sendRuntime("Order: " .. playersListString())
  sendRuntime(string.format("Game starts at /roll 1-%d.", G.currentMax))
  announceCurrentTurn()
end

------------------------------------------------------------
-- Lobby bootstrap (Managed)
------------------------------------------------------------
local function openLobby(opts)
  G.active = true; G.phase = "lobby"; G.host = playerFull()
  wipe(G.players); wipe(G.joined); wipe(G.byShort); wipe(G.seedRolls); wipe(G.rollCount)

  G.lobby = PsyLobby.StartManaged({
    gameName     = "PsyRoll",
    joinPtnPlain = "!play",
    joinPtnStake = "^!play%s+stake%s+(%d+)$",
    allowStake   = true,
    maxStake     = 1000000,

    -- timings / capacity
    solo        = opts.solo or false,
    maxPlayers  = opts.maxPlayers or G.maxPlayers or 5,
    duration    = opts.duration or 30,
    warnAt      = 10,

    -- use your routing: start-time uses chosen channel; runtime avoids SAY
    startFn     = function(m) if m and m~="" then sendStart(m)   end end,
    runtimeFn   = function(m) if m and m~="" then sendRuntime(m) end end,

    -- mirrors
    onJoin = function(_, full)
      G.byShort[short(full):lower()] = full
      G.rollCount[full] = 0
    end,

    onWarn = function(lobby)
      sendRuntime("Lobby closing in 10 seconds.")
      sendRuntime("Waiting: " .. lobby:PlayersListString())
    end,

    onClose = function(lobby)
      -- copy final player list
      wipe(G.players); for i,full in ipairs(lobby.players) do G.players[i]=full end
      wipe(G.joined);  for _,full in ipairs(lobby.players) do G.joined[full]=true end

      -- capture stake (if used)
      if lobby._stakeEnabled and lobby._stakeGold and lobby._stakeGold > 0 then
        G.stakeGold = lobby._stakeGold
      end

      local minP = lobby.minPlayers or 2
      if #G.players < minP then
        sendRuntime("Not enough players joined. Game cancelled.")
        resetAll(); return
      end

      -- move into seeding
      G.phase = "seeding"; wipe(G.seedRolls)
      sendRuntime("Players: " .. playersListString())
      sendRuntime("Everyone please /roll 1-100 once. Highest starts. (One seed roll each.)")

      if G.stakeGold > 0 then
        local pot = math.max(0, (#G.players - 1)) * G.stakeGold
        sendRuntime(string.format("Stake: %s each. Winner takes %s.",
          formatGold(G.stakeGold), formatGold(pot)))
      end
    end,

    onCancel = function(_, reason)
      if reason == "not_enough" then
        sendRuntime("Not enough players joined. Game cancelled.")
      else
        sendRuntime("Lobby cancelled.")
      end
      resetAll()
    end,
  })

  -- Solo convenience: auto-join host so it proceeds immediately
  if opts.solo then
    G.lobby:AddPlayer(G.host)
    wipe(G.joined); for _,full in ipairs(G.lobby.players) do G.joined[full]=true end
  end
end

------------------------------------------------------------
-- System rolls handler (locale-safe + robust name resolution)
------------------------------------------------------------
-- Build a locale-safe pattern from Blizzard's global string (e.g., "%s rolls %d (%d-%d).")
local function buildRollPattern()
  local templ = RANDOM_ROLL_RESULT or "%s rolls %d (%d-%d)."
  -- escape Lua pattern magic, then replace %s/%d with capture groups
  templ = templ:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
  templ = templ:gsub("%%s", "(.+)")    -- player name (may be "Name" or "Name-Realm")
  templ = templ:gsub("%%d", "(%%d+)")  -- numbers
  -- make trailing punctuation optional if template doesn't already force it
  if not templ:match("%.%$") then
    templ = templ:gsub("%$$", "%%.?$")
  end
  return "^" .. templ .. "$"
end

local ROLL_PATTERN     = buildRollPattern()
-- Generic English-ish fallback (helps if RANDOM_ROLL_RESULT is unusual)
local ROLL_FALLBACK_RE = "^(.+)%s+[Rr]olls?%s+(%d+)%s*%((%d+)%-(%d+)%)%.?$"

-- Try hard to map the system message "name" to a full Name-Realm in G.players
local function resolveFullFromChatName(chatName)
  if not chatName or chatName == "" then return nil end
  local s = chatName

  -- 1) Exact short map (case-insensitive)
  local m = G.byShort[(s or ""):lower()]
  if m then return m end

  -- 2) If chatName already looks like Full (has a hyphen), try direct/full match
  if s:find("-", 1, true) then
    for _,full in ipairs(G.players) do
      if full:lower() == s:lower() then return full end
    end
    -- also try just the short part again
    local sn = s:match("^[^-]+")
    if sn then
      local mm = G.byShort[sn:lower()]
      if mm then return mm end
    end
  end

  -- 3) Try appending our normalized realm
  local guess = s .. "-" .. normalizedRealm()
  for _,full in ipairs(G.players) do
    if full:lower() == guess:lower() then return full end
  end

  -- 4) Fallback: scan players by short name case-insensitively
  for _,full in ipairs(G.players) do
    if short(full):lower() == s:lower() then return full end
  end
  return nil
end

local function everyoneSeeded()
  for _,p in ipairs(G.players) do
    if not G.seedRolls[p] then return false end
  end
  return true
end

local function onSystemRoll(sysmsg)
  -- parse using locale pattern, then fallback
  local whoText, rStr, lowStr, highStr = (sysmsg or ""):match(ROLL_PATTERN)
  if not whoText then
    whoText, rStr, lowStr, highStr = (sysmsg or ""):match(ROLL_FALLBACK_RE)
  end
  if not whoText then return end

  local roll  = tonumber(rStr)
  local low   = tonumber(lowStr)
  local high  = tonumber(highStr)
  if not (roll and low and high) then return end

  -- ===== Seeding phase =====
  if G.active and G.phase == "seeding" then
    if low ~= 1 or high ~= 100 then return end

    -- Try to map name → full; if solo and map fails, assume the only player
    local full = resolveFullFromChatName(whoText)
    if not full and #G.players == 1 then
      full = G.players[1]
    end
    if not full or not G.joined[full] or G.seedRolls[full] then return end

    G.seedRolls[full] = roll
    sendRuntime(string.format("Seed — %s: %d", short(full), roll))

    if everyoneSeeded() then
      -- order by roll high→low (tie-breaker: short name)
      local t={}; for _,p in ipairs(G.players) do t[#t+1]={p=p, r=G.seedRolls[p] or -1} end
      table.sort(t,function(a,b) if a.r==b.r then return short(a.p)<short(b.p) end return a.r>b.r end)
      wipe(G.players); for _,v in ipairs(t) do table.insert(G.players, v.p) end
      beginPlaying()
    end
    return
  end

  -- ===== Playing phase =====
  if G.active and G.phase == "playing" then
    if low ~= 1 or high ~= G.currentMax then return end

    local whoFull = resolveFullFromChatName(whoText)
    if not whoFull and #G.players == 1 then whoFull = G.players[1] end
    if not whoFull or whoFull ~= G.players[G.turn] then return end

    G.rollCount[whoFull] = (G.rollCount[whoFull] or 0) + 1

    if roll == 1 then
      local rc = G.rollCount[whoFull] or 1
      sendRuntime(string.format("%s rolled 1 and WINS!  (rolls this game: %d)", short(whoFull), rc))
      if (G.stakeGold or 0) > 0 then
        local pot = math.max(0, (#G.players - 1)) * G.stakeGold
        sendRuntime(string.format("Stake result — %s wins %s. Losers pay %s each.",
          short(whoFull), formatGold(pot), formatGold(G.stakeGold)))
      end
      if type(_G.PsyRoll_Stats_EndGame) == "function" then
        _G.PsyRoll_Stats_EndGame(whoFull)
      end
      resetAll()
      return
    end

    local nextIndex = (G.turn % #G.players) + 1
    local nextPlayer = G.players[nextIndex]
    sendRuntime(string.format("%s rolled %d!  %s you're next — /roll 1-%d",
      short(whoFull), roll, short(nextPlayer), roll))

    G.currentMax = roll
    G.turn = nextIndex
    resetTimers()
    setTurnTimer()
  end
end

------------------------------------------------------------
-- Slash command
------------------------------------------------------------
SLASH_PSYROLL1 = "/psyroll"
SlashCmdList.PSYROLL = function(msg)
  msg = trim(msg or "")
  local a = splitWords(msg)
  local a1 = (a[1] or ""):lower()

  -- channel pref
  if a1 == "channel" then
    local opt=(a[2] or ""):lower()
    if opt=="" or opt=="auto" then GPref.startChan="AUTO"; printLocal("Start channel: AUTO")
    elseif opt=="say" then GPref.startChan="SAY"; printLocal("Start channel: SAY")
    elseif opt=="party" then GPref.startChan="PARTY"; printLocal("Start channel: PARTY")
    elseif opt=="raid" then GPref.startChan="RAID"; printLocal("Start channel: RAID")
    elseif opt=="instance" or opt=="instance_chat" then GPref.startChan="INSTANCE_CHAT"; printLocal("Start channel: INSTANCE_CHAT")
    elseif opt=="emote" then GPref.startChan="EMOTE"; printLocal("Start channel: EMOTE")
    elseif opt=="whisper" then
      local who=a[3] or ""
      if who=="" then printLocal("Usage: /psyroll channel whisper <Name>")
      else GPref.startChan="WHISPER"; GPref.whisperTo=who; Last.whisperTo=who; printLocal("Start channel: WHISPER → "..who) end
    else
      printLocal("Usage: /psyroll channel [auto|say|party|raid|instance|emote|whisper <Name>]")
    end
    return
  end

  -- stats (local prints) + wipes
  if a1 == "stats" then
    local sub=(a[2] or ""):lower()
    if sub=="reset" or sub=="wipe" then
      local target=a[3] or ""
      if target~="" and target:lower()=="all" then
        if type(_G.PsyRoll_Stats_ResetAll) == "function" then _G.PsyRoll_Stats_ResetAll(); printLocal("All PsyRoll stats wiped.")
        else printLocal("Stats module not loaded.") end
      else
        local who=(target~="" and target) or UnitName("player")
        if type(_G.PsyRoll_Stats_ResetPlayer) == "function" then
          local full=_G.PsyRoll_Stats_ResetPlayer(who)
          local n,r=full:match("^([^-]+)%-(.+)$"); printLocal(string.format("Stats wiped for %s-%s.", n or full, r or ""))
        else
          printLocal("Stats module not loaded.")
        end
      end
      return
    end
    local targetInput=(a[2] and a[2]~="") and a[2] or UnitName("player")
    if type(_G.PsyRoll_Stats_GetSummary) == "function" then
      local s=_G.PsyRoll_Stats_GetSummary(targetInput)
      printLocal(string.format("Stats for %s-%s", s.name, s.realm))
      printLocal(string.format("W:%d L:%d  (Friendly %d/%d, Staked %d/%d)", s.totalWins,s.totalLosses,s.friendlyWins,s.friendlyLosses,s.stakedWins,s.stakedLosses))
      printLocal(string.format("Gold — Won %dg, Lost %dg, Net %dg", s.goldWon,s.goldLost,s.netGold))
      printLocal(string.format("Nemesis: %s (%d)  |  Victim: %s (%d)", s.nemesis or "—", s.nemesisCount or 0, s.victim or "—", s.victimCount or 0))
      printLocal(string.format("Gold drain: %s (%dg)  |  Gold source: %s (%+dg)", s.goldDrain or "—", s.goldDrainAmt or 0, s.goldSource or "—", s.goldSourceNet or 0))
    else
      printLocal("Stats module not loaded.")
    end
    return
  end

  -- solo
  if a1 == "solo" then
    if G.active and (G.phase=="lobby" or G.phase=="seeding" or G.phase=="playing") then
      printLocal("A game is already running. Use /psyroll stop to cancel."); return
    end
    resetAll()
    G.startMax = math.max(2, tonumber(a[2]) or 1000)
    G.stakeGold = math.max(0, tonumber(a[3]) or 0)
    openLobby({ solo=true, maxPlayers=1, duration=30 })
    return
  end

  -- skip (advance turn)
  if a1 == "skip" then
    if not (G.active and G.phase=="playing") then return end
    G.turn = (G.turn % #G.players) + 1
    sendRuntime("(skipped turn)")
    announceCurrentTurn()
    return
  end

  -- stop (cancel lobby or game)
  if a1 == "stop" then
    if G.lobby and G.lobby.active then G.lobby:Stop("stopped")
    else if G.active and (G.phase=="seeding" or G.phase=="playing") then sendRuntime("Game cancelled.") end end
    resetAll()
    return
  end

  -- normal lobby: /psyroll [maxPlayers] [startMax] [stakeGold]
  local mp, sm, sg = tonumber(a[1]), tonumber(a[2]), tonumber(a[3])
  if a1 ~= "" and not mp then
    printLocal("Usage:")
    printLocal("  /psyroll [maxPlayers] [startMax] [stakeGold]")
    printLocal("  /psyroll solo [startMax] [stakeGold]")
    printLocal("  /psyroll channel [auto|say|party|raid|instance|emote|whisper <Name>]")
    printLocal("  /psyroll skip | /psyroll stop | /psyroll stats [Name] | /psyroll stats reset [Name|all]")
    return
  end

  if G.active and (G.phase=="lobby" or G.phase=="seeding" or G.phase=="playing") then
    printLocal("A game is already running. Use /psyroll stop to cancel."); return
  end

  resetAll()
  G.maxPlayers = math.max(2, math.min(mp or 5, 40))
  G.startMax   = math.max(2, sm or 1000)
  G.stakeGold  = math.max(0, sg or 0)
  openLobby({ solo=false, maxPlayers=G.maxPlayers, duration=30 })
end

------------------------------------------------------------
-- Events: system rolls + learn last used channel
------------------------------------------------------------
local EVENTS = {
  "CHAT_MSG_SAY","CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER",
  "CHAT_MSG_RAID","CHAT_MSG_RAID_LEADER",
  "CHAT_MSG_INSTANCE_CHAT","CHAT_MSG_INSTANCE_CHAT_LEADER",
  "CHAT_MSG_WHISPER_INFORM","CHAT_MSG_SYSTEM",
}
for _,ev in ipairs(EVENTS) do f:RegisterEvent(ev) end

f:SetScript("OnEvent", function(_, event, ...)
  if event ~= "CHAT_MSG_SYSTEM" then
    updateLastChannel(event, ...)
    return
  end
  local msg = ...
  onSystemRoll(msg or "")
end)
