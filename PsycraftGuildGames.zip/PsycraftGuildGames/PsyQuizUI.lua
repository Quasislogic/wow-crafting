-- PsyQuizUI.lua — pick-on-click image swap + correct-vs-picked end image + scores panel + timer
-- Public API:
--   PsyQuizUI.Show(question, choices, onSelect[, headerText][, seconds])
--   PsyQuizUI.Hide()
--   PsyQuizUI.RevealCorrect(correctIdx[, myPickIdx][, holdSeconds])
--   PsyQuizUI.SetScores(scoresTableOrMap)
--   PsyQuizUI.ShowScores(showBool)
--   PsyQuizUI.RefreshScores()
--   PsyQuizUI.StartTimer(seconds)
--   PsyQuizUI.StopTimer()

local ADDON = "PsyQuizUI"
local UI = {}
_G.PsyQuizUI = UI

-- ------------ Layout knobs ------------
local FRAME_W, FRAME_H = 720, 380
local GRID_TOP_Y   = -175
local GRID_START_X = -250
local COL_GAP_X    = 10
local ROW_GAP_Y    = 5
local COL_WIDTH    = 320
local BTN_H        = 48

-- Scores panel
local SCORE_W      = 220
local SCORE_ROW_H  = 20
local SCORE_PAD    = 10

-- Timer bar
local TIMER_W      = 520
local TIMER_H      = 10
local TIMER_Y      = -96 -- under the title, above the question

-- ------------ Media -------------------
local MEDIA = "Interface\\AddOns\\PsycraftGuildGames\\media\\"
local TEX = {
  border = MEDIA .. "quiz-border.tga",
  font   = MEDIA .. "Montserrat-SemiBold.ttf",

  -- 3-slice sets (Left/Mid/Right for Normal/Hover/Pressed)
  L_N = MEDIA .. "quiz-btn-left-N.tga",
  M_N = MEDIA .. "quiz-btn-mid-N.tga",
  R_N = MEDIA .. "quiz-btn-right-N.tga",
  L_H = MEDIA .. "quiz-btn-left-H.tga",
  M_H = MEDIA .. "quiz-btn-mid-H.tga",
  R_H = MEDIA .. "quiz-btn-right-H.tga",
  L_P = MEDIA .. "quiz-btn-left-P.tga",
  M_P = MEDIA .. "quiz-btn-mid-P.tga",
  R_P = MEDIA .. "quiz-btn-right-P.tga",
}

-- Backgrounds
local LABEL = { "A","B","C","D","E","F","G","H" }

-- 0) default question background
local BG_DEFAULT = MEDIA .. "quiz-bg-0.tga"

-- 1) pick images: pick-A.tga, pick-B.tga, pick-C.tga, pick-D.tga
local function PICK_BG(pickLetter)
  return MEDIA .. ("pick-%s.tga"):format(pickLetter)
end

-- 2) end-state images:
--    end-A.tga, end-B.tga, end-C.tga, end-D.tga
--    end-A_B.tga, end-A_C.tga, ... end-D_C.tga
local function END_BG(correctLetter, pickLetterOrNil)
  if pickLetterOrNil and pickLetterOrNil ~= correctLetter then
    return MEDIA .. ("end-%s.tga"):format(correctLetter, pickLetterOrNil)
  end
  return MEDIA .. ("end-%s.tga"):format(correctLetter)
end

local function hasTex(path) return type(path)=="string" and path~="" end

local function applyFont(fs, size)
  if hasTex(TEX.font) and fs.SetFont and fs:SetFont(TEX.font, size, "OUTLINE") then return end
  fs:SetFontObject(GameFontNormal)
  fs:SetTextHeight(size)
end

local function sndHover() if PlaySound then PlaySound(841) end end
local function sndClick() if PlaySound then PlaySound(852) end end

-- ------------ Root Frame --------------
local f = CreateFrame("Frame", "PsyQuizFrame", UIParent, "BackdropTemplate")
f:SetSize(FRAME_W, FRAME_H)
f:SetPoint("CENTER", 0, 40)
f:Hide()
f:SetFrameStrata("DIALOG")

if f.SetPropagateKeyboardInput then f:SetPropagateKeyboardInput(true) end

-- Background / Border
local bg = f:CreateTexture(nil, "BACKGROUND")
bg:SetAllPoints(true)
bg:SetTexture(BG_DEFAULT)
f.bgTex = bg

if hasTex(TEX.border) then
  local b = f:CreateTexture(nil, "BORDER")
  b:SetAllPoints(true)
  b:SetTexture(TEX.border)
else
  f:SetBackdrop({
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    edgeSize = 16,
    insets = { left = 8, right = 8, top = 8, bottom = 8 }
  })
  f:SetBackdropBorderColor(0.2, 0.6, 1.0, 1)
end

local function SetBackground(path)
  if path and path ~= "" then f.bgTex:SetTexture(path) end
end

-- Title
local title = f:CreateFontString(nil, "OVERLAY")
applyFont(title, 20)
title:SetPoint("TOP", 0, -18)
title:SetText("|cff80c0ffPsyQuiz|r")

-- === Timer Bar ===
local timerFrame = CreateFrame("Frame", nil, f)
timerFrame:SetSize(TIMER_W, TIMER_H)
timerFrame:SetPoint("TOP", 0, TIMER_Y)

local timerBG = timerFrame:CreateTexture(nil, "BACKGROUND")
timerBG:SetAllPoints(true)
timerBG:SetColorTexture(0, 0, 0, 0.35)

local timerFill = timerFrame:CreateTexture(nil, "ARTWORK")
timerFill:SetPoint("LEFT", timerFrame, "LEFT", 0, 0)
timerFill:SetSize(TIMER_W, TIMER_H)
timerFill:SetColorTexture(0.2, 0.8, 0.3, 0.85)

local timerBorder = timerFrame:CreateTexture(nil, "OVERLAY")
timerBorder:SetAllPoints(true)
timerBorder:SetColorTexture(1,1,1,0.08)

-- seconds label to the right of the bar
local timerText = f:CreateFontString(nil, "OVERLAY")
applyFont(timerText, 12)
timerText:SetPoint("LEFT", timerFrame, "RIGHT", 6, 0)
timerText:SetText("")

-- timer state
local timerTicker   = nil
local timerEndAt    = 0
local timerTotalSec = 0

local function updateTimerVisual()
  if timerTotalSec <= 0 then
    timerFill:SetWidth(0.0001)
    timerText:SetText("")
    return
  end
  local now = GetTime and GetTime() or 0
  local remain = math.max(0, timerEndAt - now)
  local pct = math.max(0, math.min(1, remain / timerTotalSec))
  timerFill:SetWidth(TIMER_W * pct)
  timerText:SetText(string.format("%ds", math.ceil(remain)))
end

local function stopTimerInternal()
  if timerTicker and timerTicker.Cancel then timerTicker:Cancel() end
  timerTicker = nil
  timerEndAt = 0
  timerTotalSec = 0
  timerFill:SetWidth(0.0001)
  timerText:SetText("")
end

function UI.StartTimer(seconds)
  seconds = tonumber(seconds) or 0
  stopTimerInternal()
  if seconds <= 0 then return end
  timerTotalSec = seconds
  timerEndAt = (GetTime and GetTime() or 0) + seconds
  timerFrame:Show()
  updateTimerVisual()
  -- smooth countdown (10 Hz)
  timerTicker = C_Timer.NewTicker(0.1, function()
    updateTimerVisual()
    if (GetTime and GetTime() or 0) >= timerEndAt then
      stopTimerInternal()
    end
  end)
end

function UI.StopTimer()
  stopTimerInternal()
end

-- Question
local q = f:CreateFontString(nil, "OVERLAY")
applyFont(q, 14)
q:ClearAllPoints()
q:SetPoint("TOP", 5, -130)
q:SetWidth(520)
q:SetJustifyH("CENTER")
q:SetWordWrap(true)
q:SetSpacing(2)
q:SetText("Question goes here")

-- 3-slice button factory
local CAP_W = 44

local function makeSliceSet(parent, layer, L, M, R)
  local tL = parent:CreateTexture(nil, layer); tL:SetSize(CAP_W, BTN_H)
  local tM = parent:CreateTexture(nil, layer); tM:SetHeight(BTN_H)
  local tR = parent:CreateTexture(nil, layer); tR:SetSize(CAP_W, BTN_H)
  if hasTex(L) then tL:SetTexture(L) else tL:SetColorTexture(0.06,0.10,0.16,0.95) end
  if hasTex(M) then tM:SetTexture(M) else tM:SetColorTexture(0.06,0.10,0.16,0.95) end
  if hasTex(R) then tR:SetTexture(R) else tR:SetColorTexture(0.06,0.10,0.16,0.95) end
  if tM.SetHorizTile then tM:SetHorizTile(true) end
  return {
    L=tL, M=tM, R=tR,
    Show=function(s) s.L:Show(); s.M:Show(); s.R:Show() end,
    Hide=function(s) s.L:Hide(); s.M:Hide(); s.R:Hide() end
  }
end

local function layoutSlices(set, owner)
  set.L:ClearAllPoints(); set.L:SetPoint("LEFT", owner, "LEFT", 0, 0)
  set.M:ClearAllPoints(); set.M:SetPoint("LEFT", set.L, "RIGHT", 0, 0); set.M:SetPoint("RIGHT", owner, "RIGHT", -CAP_W, 0)
  set.R:ClearAllPoints(); set.R:SetPoint("RIGHT", owner, "RIGHT", 0, 0)
end

-- Answer button (text only)
local function makeAnswer(parent, idx)
  local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
  btn:SetSize(COL_WIDTH, BTN_H)

  local S_N = makeSliceSet(btn, "BACKGROUND", TEX.L_N, TEX.M_N, TEX.R_N)
  local S_H = makeSliceSet(btn, "ARTWORK",    TEX.L_H, TEX.M_H, TEX.R_H)
  local S_P = makeSliceSet(btn, "OVERLAY",    TEX.L_P, TEX.M_P, TEX.R_P)
  S_H:Hide(); S_P:Hide()

  btn:SetScript("OnEnter", function() S_H:Show(); sndHover() end)
  btn:SetScript("OnLeave", function() S_H:Hide() end)

  btn:SetScript("OnSizeChanged", function(self)
    layoutSlices(S_N, self); layoutSlices(S_H, self); layoutSlices(S_P, self)
  end)
  layoutSlices(S_N, btn); layoutSlices(S_H, btn); layoutSlices(S_P, btn)

  local text = btn:CreateFontString(nil, "OVERLAY")
  applyFont(text, 14)
  text:SetPoint("LEFT", 14, 0)
  text:SetPoint("RIGHT", -16, 0)
  text:SetJustifyH("LEFT")
  text:SetWordWrap(true)
  text:SetText("Answer "..idx)

  btn.SetAnswerText = function(_, s) text:SetText(s or "") end
  btn.SetSelected = function(_, sel)
    if sel then
      text:SetTextColor(1, 0.95, 0.5); S_H:Hide(); S_P:Show()
    else
      text:SetTextColor(1, 1, 1); S_P:Hide()
    end
  end

  btn:SetScript("OnEnable",  function() text:SetAlpha(1) end)
  btn:SetScript("OnDisable", function() text:SetAlpha(0.8); S_H:Hide() end)

  return btn
end

-- Build 2x2 grid
local answers = {}
for i = 1, 4 do answers[i] = makeAnswer(f, i) end
for i = 1, 4 do
  local col = (i - 1) % 2
  local row = math.floor((i - 1) / 2)
  local x = GRID_START_X + col * (COL_WIDTH + COL_GAP_X)
  local y = GRID_TOP_Y    - row * (BTN_H + ROW_GAP_Y)
  answers[i]:ClearAllPoints()
  answers[i]:SetPoint("TOPLEFT", f, "TOP", x, y)
end

-- Close button
local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", 2, 2)

-- Keyboard
f:SetScript("OnShow", function() if f.EnableKeyboard then f:EnableKeyboard(true) end end)
f:SetScript("OnHide",  function() if f.EnableKeyboard then f:EnableKeyboard(false) end end)
f:SetScript("OnKeyDown", function(self, key)
  if key == "ESCAPE" then self:Hide() return end
  if key == "1" or key == "NUMPAD1" then answers[1]:Click() end
  if key == "2" or key == "NUMPAD2" then answers[2]:Click() end
  if key == "3" or key == "NUMPAD3" then answers[3]:Click() end
  if key == "4" or key == "NUMPAD4" then answers[4]:Click() end
end)

-- Track last pick (for UI-only fallback if controller didn't pass it)
local lastPickIdx = nil

-- ================== Scores Panel ==================
local scorePanel = CreateFrame("Frame", "PsyQuizScorePanel", f, "BackdropTemplate")
scorePanel:SetSize(SCORE_W, FRAME_H)
scorePanel:SetPoint("TOPRIGHT", f, "TOPLEFT", -8, 0)

-- Border/backdrop
if not hasTex(TEX.border) then
  scorePanel:SetBackdrop({
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    bgFile   = "Interface\\ChatFrame\\ChatFrameBackground",
    edgeSize = 12,
    insets   = { left = 6, right = 6, top = 6, bottom = 6 }
  })
  scorePanel:SetBackdropBorderColor(0.2, 0.6, 1.0, 1)
  scorePanel:SetBackdropColor(0, 0, 0, 0.45)
else
  local bg2 = scorePanel:CreateTexture(nil, "BACKGROUND")
  bg2:SetAllPoints(true)
  bg2:SetColorTexture(0, 0, 0, 0.45)
  local b2 = scorePanel:CreateTexture(nil, "BORDER")
  b2:SetAllPoints(true)
  b2:SetTexture(TEX.border)
end

-- Header
local scoreTitle = scorePanel:CreateFontString(nil, "OVERLAY")
applyFont(scoreTitle, 16)
scoreTitle:SetPoint("TOPLEFT", SCORE_PAD, -12)
scoreTitle:SetPoint("TOPRIGHT", -SCORE_PAD, -12)
scoreTitle:SetJustifyH("CENTER")
scoreTitle:SetText("|cff80ff80Scores|r")

-- ScrollFrame
local scroll = CreateFrame("ScrollFrame", "PsyQuizScoreScroll", scorePanel, "UIPanelScrollFrameTemplate")
scroll:SetPoint("TOPLEFT", SCORE_PAD, -36)
scroll:SetPoint("BOTTOMRIGHT", -SCORE_PAD, 10)

local scrollChild = CreateFrame("Frame", nil, scroll)
scroll:SetScrollChild(scrollChild)
scrollChild:SetPoint("TOPLEFT")
scrollChild:SetSize(SCORE_W - 2*SCORE_PAD - 24, 100)

-- Column headers
local hdr = scrollChild:CreateFontString(nil, "OVERLAY")
applyFont(hdr, 12)
hdr:SetPoint("TOPLEFT", 2, 0)
hdr:SetPoint("TOPRIGHT", -2, 0)
hdr:SetJustifyH("LEFT")
hdr:SetText("|cffaaaaaa#  Name|r")
local hdr2 = scrollChild:CreateFontString(nil, "OVERLAY")
applyFont(hdr2, 12)
hdr2:SetPoint("TOPRIGHT", -2, 0)
hdr2:SetJustifyH("RIGHT")
hdr2:SetText("|cffaaaaaaScore|r")

-- Row pool
local rows = {}
local function getRow(i)
  if rows[i] then return rows[i] end
  local yOff = -((i) * SCORE_ROW_H)
  local row = CreateFrame("Frame", nil, scrollChild)
  row:SetPoint("TOPLEFT", 0, yOff)
  row:SetPoint("RIGHT", 0, 0)
  row:SetHeight(SCORE_ROW_H)

  local zebra = row:CreateTexture(nil, "BACKGROUND")
  zebra:SetAllPoints(true)
  if i % 2 == 0 then zebra:SetColorTexture(1,1,1,0.02) else zebra:SetColorTexture(0,0,0,0.02) end

  row.rank = row:CreateFontString(nil, "OVERLAY")
  applyFont(row.rank, 12)
  row.rank:SetPoint("LEFT", 3, 0)
  row.rank:SetWidth(24)
  row.rank:SetJustifyH("LEFT")

  row.name = row:CreateFontString(nil, "OVERLAY")
  applyFont(row.name, 12)
  row.name:SetPoint("LEFT", row.rank, "RIGHT", 3, 0)
  row.name:SetPoint("RIGHT", -42, 0)
  row.name:SetJustifyH("LEFT")

  row.score = row:CreateFontString(nil, "OVERLAY")
  applyFont(row.score, 12)
  row.score:SetPoint("RIGHT", -2, 0)
  row.score:SetJustifyH("RIGHT")

  rows[i] = row
  return row
end

-- Stored scores
local currentScores = {}

local function normalizeScores(scores)
  wipe(currentScores)
  if type(scores) ~= "table" then return end
  local isArray = (#scores > 0)
  if isArray then
    for _, v in ipairs(scores) do
      local name = v.name or v[1]
      local sc   = tonumber(v.score or v[2]) or 0
      if name and name ~= "" then
        table.insert(currentScores, { name = tostring(name), score = sc })
      end
    end
  else
    for k, v in pairs(scores) do
      local name = tostring(k)
      local sc   = tonumber(v) or 0
      if name and name ~= "" then
        table.insert(currentScores, { name = name, score = sc })
      end
    end
  end
  table.sort(currentScores, function(a,b)
    if a.score ~= b.score then return a.score > b.score end
    return (a.name or "") < (b.name or "")
  end)
end

local function renderScores()
  local n = #currentScores
  for i = 1, n do
    local r = getRow(i)
    local e = currentScores[i]
    r.rank:SetText(string.format("%d.", i))
    r.name:SetText(e.name or "?")
    r.score:SetText(tostring(e.score or 0))
    r:Show()
  end
  for i = n+1, #rows do
    if rows[i] then rows[i]:Hide() end
  end
  local totalH = (n * SCORE_ROW_H) + SCORE_ROW_H
  scrollChild:SetHeight(math.max(totalH, 100))
end

function UI.SetScores(scores)
  normalizeScores(scores)
  renderScores()
end

function UI.RefreshScores()
  renderScores()
end

function UI.ShowScores(show)
  if show == nil then show = true end
  if show then scorePanel:Show() else scorePanel:Hide() end
end

-- ================== Public Quiz API ==================
local currentCallback
function UI.Show(question, choices, onSelect, headerText, secondsOpt)
  title:SetText(headerText or "|cff80c0ffPsyQuiz|r")
  q:SetText(question or "")
  SetBackground(BG_DEFAULT)
  lastPickIdx = nil
  for i = 1, 4 do
    answers[i]:SetWidth(COL_WIDTH)
    answers[i]:SetHeight(BTN_H)
    answers[i]:SetAnswerText(choices and choices[i] or ("Choice "..i))
    answers[i]:SetSelected(false)
    answers[i]:SetEnabled(true)
  end
  currentCallback = onSelect
  f:Show()
  f:Raise()
  scorePanel:Show()

  if type(secondsOpt) == "number" and secondsOpt > 0 then
    UI.StartTimer(secondsOpt)
  else
    UI.StopTimer()
  end
end

function UI.Hide()
  f:Hide()
end

function UI.RevealCorrect(correctIdx, myPickIdx, _holdSeconds)
  local cL = LABEL[correctIdx or 1] or "A"
  local pIdx = myPickIdx or lastPickIdx
  local pL = (pIdx and LABEL[pIdx]) or nil
  SetBackground(END_BG(cL, pL))
  for k = 1, 4 do
    answers[k]:SetEnabled(false)
    answers[k]:SetSelected(k == (pIdx or 0))
  end
  UI.StopTimer()
end

-- Hook clicks -> (1) swap to my-pick image, (2) lock selection, (3) callback
local function wireClicks()
  for i = 1, 4 do
    answers[i]:SetScript("OnClick", function()
      sndClick()
      lastPickIdx = i

      local pickLetter = LABEL[i] or "A"
      SetBackground(PICK_BG(pickLetter))

      for k = 1, 4 do
        answers[k]:SetEnabled(false)
        answers[k]:SetSelected(k == i)
      end

      C_Timer.After(0.15, function()
        if type(currentCallback) == "function" then
          local cb = currentCallback; currentCallback = nil; cb(i)
        end
      end)
    end)
  end
end
wireClicks()
