-- PsyBlackjack.lua — Blackjack built on PsyLobby (Managed)
-- Bets, Banks, Highscores, and a short "Place your bets!" window before dealing.
-- Session-only (no SavedVariables). Players set bets with !bet N (or /psybj bet N).
-- Turn actions via chat: "hit"/"stand" (also "h"/"s").

local ADDON = "PsyBlackjack"
local f = CreateFrame("Frame")

------------------------------------------------------------
-- Utils
------------------------------------------------------------
local function trim(s) return (s or ""):gsub("^%s+",""):gsub("%s+$","") end
local function short(full) return (full and full:match("^[^-]+")) or (full or "?") end

local function normalizedRealm()
  local r = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "UnknownRealm"
  return (r or "UnknownRealm"):gsub("%s+","")
end
local function playerFull()
  local n = (UnitName and UnitName("player")) or "Player"
  return n .. "-" .. normalizedRealm()
end

local function printLocal(msg) print(string.format("|cff00ff88[%s]|r %s", ADDON, msg)) end

-- Timer helper (Classic/MoP friendly)
local function NewTimer(delay, fn)
  if C_Timer and C_Timer.NewTimer then return C_Timer.NewTimer(delay, fn) end
  local t = { _cancelled=false }
  function t:Cancel() self._cancelled=true end
  C_Timer.After(delay, function() if not t._cancelled then fn() end end)
  return t
end

-- Chat safety: escape literal pipes so WoW doesn't think they're control codes
local function SendChatSafe(msg, chan)
  if not msg or msg == "" then return end
  msg = tostring(msg):gsub("|", "||")
  SendChatMessage(msg, chan)
end

------------------------------------------------------------
-- Chat routing
-- Start-time blurbs: SAY (fallback EMOTE)
-- Runtime: INSTANCE → RAID → PARTY → EMOTE (never SAY/GUILD)
------------------------------------------------------------
local function sendStart(msg)
  local inInstance = IsInInstance and IsInInstance()
  if inInstance then
    SendChatSafe(msg, "EMOTE")
  else
    SendChatSafe(msg, "SAY")
  end
end
local function sendRuntime(msg)
  if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE) then
    SendChatSafe(msg, "INSTANCE_CHAT"); return
  end
  if IsInRaid and IsInRaid() then
    SendChatSafe(msg, "RAID"); return
  end
  if IsInGroup and IsInGroup() then
    SendChatSafe(msg, "PARTY"); return
  end
  SendChatSafe(msg, "EMOTE")
end

------------------------------------------------------------
-- Game state
------------------------------------------------------------
local BJ = {
  lobby      = nil,
  active     = false,
  phase      = "idle",     -- idle | lobby | betting | deal | turns | dealer | results | ended
  host       = nil,

  players    = {},         -- array of full names (turn order)
  joinedSet  = {},         -- full -> true
  byShort    = {},         -- lower(short) -> full

  deck       = {},
  hands      = {},         -- full -> {cards={}, stood=false, bust=false, bj=false}
  dealer     = { cards = {} },

  turnIndex  = 1,
  turnTimer  = nil,
  TURN_TIME  = 25,         -- seconds per player turn

  -- Bets & Banks
  bets       = {},         -- full -> per-hand bet (set during lobby/betting)
  bank       = {},         -- full -> chips (starts at 100 on first sit)
  peakBank   = {},         -- full -> highest bank observed (highscores)
  defaultBet = 10,         -- fallback bet if player didn't set one
  minBet     = 1,
  maxBet     = 1000000,    -- soft cap; also constrained by bank

  -- Optional lobby stake copy (if !play stake N used) → becomes default bet
  stakeGold  = 0,

  -- Short betting window after lobby closes
  BET_WINDOW = 6,          -- seconds
  betTimer   = nil,        -- timer for betting window
}

local SUITS = {"♠","♥","♦","♣"}
local RANKS = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"}

local function newDeck()
  local d = {}
  for s=1,4 do
    for r=1,13 do d[#d+1] = { r=r, s=s } end
  end
  for i=#d,2,-1 do
    local j = math.random(i)
    d[i], d[j] = d[j], d[i]
  end
  return d
end

local function cardLabel(c)
  -- Bracketed rank + suit with a space for clarity, e.g., [Q ♥]
  return (c and ("[" .. RANKS[c.r] .. " " .. SUITS[c.s] .. "]")) or "[?]"
end
local function handLabel(list)
  local t = {}
  for i,c in ipairs(list or {}) do t[i] = cardLabel(c) end
  return (#t>0) and table.concat(t, " ") or "—"
end

-- Hand value with ace flexibility (A=11 unless bust → some become 1)
local function handValue(cards)
  local total, aces = 0, 0
  for _,c in ipairs(cards or {}) do
    if c.r == 1 then total = total + 11; aces = aces + 1
    elseif c.r >= 11 then total = total + 10
    else total = total + c.r end
  end
  while total > 21 and aces > 0 do total = total - 10; aces = aces - 1 end
  return total
end
local function isBlackjack(cards) return (#cards == 2) and (handValue(cards) == 21) end

local function dealOne(toList)
  local c = table.remove(BJ.deck)
  if not c then BJ.deck = newDeck(); c = table.remove(BJ.deck) end
  table.insert(toList, c)
  return c
end

------------------------------------------------------------
-- Bets/Bank helpers
------------------------------------------------------------
local function ensureBank(full)
  if BJ.bank[full] == nil then
    BJ.bank[full] = 100
    BJ.peakBank[full] = 100
  end
end
local function clampBet(full, amount)
  ensureBank(full)
  local b = math.floor(tonumber(amount) or 0)
  b = math.max(BJ.minBet, math.min(b, BJ.maxBet))
  b = math.min(b, BJ.bank[full]) -- cannot bet more than you have
  return b
end
local function setBet(full, amount)
  local b = clampBet(full, amount)
  BJ.bets[full] = b
  return b
end
local function updatePeak(full)
  if BJ.bank[full] and BJ.peakBank[full] then
    if BJ.bank[full] > BJ.peakBank[full] then BJ.peakBank[full] = BJ.bank[full] end
  end
end
local function announceBanks(forSeated)
  local list = {}
  if forSeated then
    for _,full in ipairs(BJ.players) do
      list[#list+1] = string.format("%s:%d", short(full), BJ.bank[full] or 0)
    end
  else
    for full,amt in pairs(BJ.bank) do
      list[#list+1] = string.format("%s:%d", short(full), amt or 0)
    end
    table.sort(list)
  end
  if #list == 0 then printLocal("No bank data yet.") else printLocal("Banks: "..table.concat(list, "  ")) end
end
local function announceHighscores()
  local t = {}
  for full,peak in pairs(BJ.peakBank) do
    t[#t+1] = { full=full, short=short(full), peak=peak or 0 }
  end
  table.sort(t, function(a,b) return (a.peak or 0) > (b.peak or 0) end)
  local parts = {}
  for i=1, math.min(8, #t) do
    parts[#parts+1] = string.format("%d) %s:%d", i, t[i].short, t[i].peak)
  end
  if #parts == 0 then printLocal("No highscores yet.") else printLocal("Highscores (peak bank): "..table.concat(parts, "  ")) end
end

-- Quick one-liner of current bets (used in betting window)
local function announceBetsLine()
  if #BJ.players == 0 then return end
  local parts = {}
  for _,full in ipairs(BJ.players) do
    local v = BJ.bets[full]
    if v == nil then
      v = (BJ.stakeGold > 0 and BJ.stakeGold) or BJ.defaultBet or 10
    end
    parts[#parts+1] = string.format("%s:%d", short(full), v)
  end
  sendRuntime("Current bets: " .. table.concat(parts, "  "))
end

------------------------------------------------------------
-- Flow helpers (timers & reset)
------------------------------------------------------------
local function clearTurnTimer() if BJ.turnTimer then BJ.turnTimer:Cancel() end; BJ.turnTimer=nil end

-- Escape hatch for stuck states
local function safeHardReset()
  if BJ.turnTimer then BJ.turnTimer:Cancel(); BJ.turnTimer = nil end
  if BJ.betTimer then BJ.betTimer:Cancel(); BJ.betTimer = nil end
  if BJ.lobby and BJ.lobby.active then BJ.lobby:Stop("reset") end
  BJ.active = false
  BJ.phase = "idle"
end

local function hardReset()
  clearTurnTimer()
  if BJ.betTimer then BJ.betTimer:Cancel(); BJ.betTimer = nil end
  BJ.active = false
  BJ.phase = "idle"
  wipe(BJ.players); wipe(BJ.joinedSet); wipe(BJ.byShort)
  wipe(BJ.bets)
  BJ.hands = {}
  BJ.dealer = { cards = {} }
  BJ.deck = {}
  BJ.turnIndex = 1
  BJ.stakeGold = 0
  if BJ.lobby and BJ.lobby.active then BJ.lobby:Stop("reset") end
  BJ.lobby = nil
end

local function endGame(reason)
  BJ.phase = "ended"
  BJ.active = false
  clearTurnTimer()
  if reason ~= "stopped" then sendRuntime("Blackjack hand complete.") else sendRuntime("Blackjack cancelled.") end
  hardReset()
end

------------------------------------------------------------
-- Core flow
------------------------------------------------------------
local function nextTurnOrDealer()
  -- move to next actionable player
  while BJ.turnIndex <= #BJ.players do
    local full = BJ.players[BJ.turnIndex]
    local h = BJ.hands[full]
    if h and not h.bust and not h.stood and not h.bj then
      sendRuntime(("%s it's your turn — type 'hit' or 'stand' (%ds)."):format(short(full), BJ.TURN_TIME))
      clearTurnTimer()
      BJ.turnTimer = NewTimer(BJ.TURN_TIME, function()
        if not h.stood and not h.bust and not h.bj then
          h.stood = true
          sendRuntime(("%s timed out → Stand."):format(short(full)))
        end
        BJ.turnIndex = BJ.turnIndex + 1
        nextTurnOrDealer()
      end)
      return
    end
    BJ.turnIndex = BJ.turnIndex + 1
  end

  -- Dealer phase
  BJ.phase = "dealer"
  clearTurnTimer()
  sendRuntime(("Dealer reveals: %s"):format(handLabel(BJ.dealer.cards)))
  local dTot = handValue(BJ.dealer.cards)

  -- Dealer hits until 17+ (stand on soft 17)
  while dTot < 17 do
    local c = dealOne(BJ.dealer.cards)
    dTot = handValue(BJ.dealer.cards)
    sendRuntime(("Dealer hits: %s (total %d)"):format(cardLabel(c), dTot))
  end
  if dTot > 21 then sendRuntime("Dealer busts!") end

  -- Results & payouts
  BJ.phase = "results"
  BJ.active = false  -- clear 'in progress' immediately to avoid stuck state
  local dFinal = handValue(BJ.dealer.cards)

  for _,full in ipairs(BJ.players) do
    ensureBank(full)
    local bet = BJ.bets[full] or BJ.defaultBet
    bet = clampBet(full, bet) -- re-clamp vs bank
    local h = BJ.hands[full]
    local pTot = handValue(h.cards)

    local delta = 0
    local outcome = ""

    if h.bj and not isBlackjack(BJ.dealer.cards) then
      delta = math.floor(bet * 1.5)
      outcome = "Blackjack! You win"
    elseif not h.bj and isBlackjack(BJ.dealer.cards) then
      delta = -bet
      outcome = "Dealer blackjack. You lose"
    elseif h.bust then
      delta = -bet
      outcome = "Bust. You lose"
    else
      if dFinal > 21 or pTot > dFinal then delta = bet; outcome = "You win"
      elseif pTot < dFinal then delta = -bet; outcome = "You lose"
      else delta = 0; outcome = "Push" end
    end

    BJ.bank[full] = (BJ.bank[full] or 0) + delta
    updatePeak(full)

    local sign = (delta >= 0) and "+" or ""
    sendRuntime(("%s: %s (%d vs dealer %d) — %s%d  || Bank: %d"):
      format(short(full), handLabel(h.cards), pTot, dFinal, sign, delta, BJ.bank[full]))
    -- Note: the "||" here is harmless; SendChatSafe will double any pipes anyway.
  end

  endGame("done")
end

local function startHand()
  BJ.phase = "deal"
  BJ.active = true
  BJ.deck = newDeck()
  BJ.hands = {}; BJ.dealer = { cards = {} }
  BJ.turnIndex = 1

  -- Validate seated players: ensure bank and resolve final bet (default if missing)
  local seated = {}
  for _,full in ipairs(BJ.players) do
    ensureBank(full)
    if (BJ.bank[full] or 0) >= BJ.minBet then
      local base = (BJ.bets[full] ~= nil) and BJ.bets[full] or (BJ.stakeGold > 0 and BJ.stakeGold or BJ.defaultBet)
      BJ.bets[full] = clampBet(full, base)
      seated[#seated+1] = full
    else
      sendRuntime(("%s has insufficient bank and is removed from the hand."):format(short(full)))
    end
  end
  BJ.players = seated
  if #BJ.players == 0 then
    sendRuntime("No eligible players with sufficient bank.")
    endGame("stopped")
    return
  end

  -- Announce bets
  announceBetsLine()

  -- Init hands & initial deal
  for _,full in ipairs(BJ.players) do
    BJ.hands[full] = { cards = {}, stood=false, bust=false, bj=false }
  end
  for i=1,2 do
    for _,full in ipairs(BJ.players) do dealOne(BJ.hands[full].cards) end
    dealOne(BJ.dealer.cards)
  end

  sendRuntime(("Starting Blackjack with %d player(s)%s."):format(#BJ.players, BJ.stakeGold>0 and (" — Default Bet "..BJ.stakeGold) or ""))

  -- Announce player hands & dealer up-card
  for _,full in ipairs(BJ.players) do
    local h = BJ.hands[full]
    if isBlackjack(h.cards) then h.bj = true end
    sendRuntime(("%s: %s (%d)"):format(short(full), handLabel(h.cards), handValue(h.cards)))
  end
  sendRuntime(("Dealer shows: %s ??"):format(cardLabel(BJ.dealer.cards[1])))

  -- If everyone has blackjack, go straight to dealer/results
  local anyTurn = false
  for _,full in ipairs(BJ.players) do if not BJ.hands[full].bj then anyTurn = true break end end
  BJ.phase = anyTurn and "turns" or BJ.phase
  nextTurnOrDealer()
end

------------------------------------------------------------
-- Managed lobby bootstrap (reuses PsyLobby)
------------------------------------------------------------
local function openBlackjackLobby(opts)
  hardReset()
  BJ.phase = "lobby"
  BJ.host  = playerFull()

  BJ.lobby = PsyLobby.StartManaged({
    gameName     = "Blackjack",
    joinPtnPlain = "!play",
    joinPtnStake = "^!play%s+stake%s+(%d+)$", -- optional shared 'stake' to become default bet
    allowStake   = true,
    maxStake     = tonumber(opts.maxBet or opts.maxStake) or BJ.maxBet,

    solo       = opts.solo or false,
    maxPlayers = opts.maxPlayers or 5,
    duration   = opts.duration or 30,
    warnAt     = 10,

    startFn   = function(m) if m and m~="" then sendRuntime(m) end end,
    runtimeFn = function(m) if m and m~="" then sendRuntime(m) end end,

    onJoin = function(_, full)
      BJ.byShort[short(full):lower()] = full
      ensureBank(full)
    end,

    onClose = function(lobby)
      wipe(BJ.players);   for i,full in ipairs(lobby.players) do BJ.players[i]=full end
      wipe(BJ.joinedSet); for _,full in ipairs(lobby.players) do BJ.joinedSet[full]=true end

      local minP = lobby.minPlayers or 2
      if #BJ.players < minP then
        sendRuntime("Not enough players for Blackjack.")
        endGame("stopped")
        return
      end

      -- Copy stake from lobby if locked → becomes default bet for this hand
      if lobby._stakeEnabled and lobby._stakeGold and lobby._stakeGold > 0 then
        BJ.stakeGold = math.min(lobby._stakeGold, lobby._maxStake or BJ.maxBet)
        BJ.defaultBet = BJ.stakeGold
      else
        BJ.stakeGold = 0
        BJ.defaultBet = 10
      end

      sendRuntime(("Blackjack lobby closed. Players: %s"):format(lobby:PlayersListString()))

      -- Short betting window before dealing
      BJ.phase = "betting"
      announceBetsLine()
      sendRuntime(("Place your bets! (%ds)  Set with !bet N  (default %d)")
        :format(BJ.BET_WINDOW or 6, (BJ.stakeGold > 0 and BJ.stakeGold) or BJ.defaultBet or 10))

      if BJ.betTimer then BJ.betTimer:Cancel() end
      BJ.betTimer = NewTimer(BJ.BET_WINDOW or 6, function()
        BJ.betTimer = nil
        startHand()
      end)
    end,

    onCancel = function(_, _why)
      sendRuntime("Blackjack lobby cancelled.")
      endGame("stopped")
    end,
  })

  -- Let players know how to set bets during the lobby
  sendRuntime(("Set your bet with '!bet N' (default %d). Bank starts at 100."):format(BJ.defaultBet or 10))

  -- Solo convenience: auto-join host
  if opts.solo then
    BJ.lobby:AddPlayer(playerFull())
    wipe(BJ.joinedSet); for _,full in ipairs(BJ.lobby.players) do BJ.joinedSet[full]=true end
  end
end

------------------------------------------------------------
-- Chat input (lobby/betting bets + turn actions)
------------------------------------------------------------
local function onChatMessage(event, msg, author)
  msg = trim((msg or "")); if msg == "" then return end

  -- Normalize sender to Full-Realm
  local aName, aRealm = strsplit("-", author or "")
  if not aRealm or aRealm == "" then author = (aName or "?") .. "-" .. normalizedRealm() end

  -- During LOBBY or BETTING: accept "!bet N" or "/bet N"
  if BJ.phase == "lobby" or BJ.phase == "betting" then
    local n = msg:match("^!bet%s+(%d+)$") or msg:match("^/bet%s+(%d+)$")
    if n then
      ensureBank(author)
      local b = setBet(author, tonumber(n))
      sendRuntime(("%s set bet to %d."):format(short(author), b))
      if BJ.phase == "betting" then announceBetsLine() end
      return
    end
  end

  -- During TURNS: only seated player whose turn it is can act
  if not (BJ.active and BJ.phase == "turns") then return end
  if not BJ.joinedSet[author] then return end

  local lower = msg:lower()
  local act = (lower == "hit" or lower == "h") and "hit" or (lower == "stand" or lower == "s") and "stand" or nil
  if not act then return end

  local current = BJ.players[BJ.turnIndex]
  if not current or current ~= author then return end

  local h = BJ.hands[author]; if not h then return end
  clearTurnTimer()

  if act == "hit" then
    local c = dealOne(h.cards)
    local tot = handValue(h.cards)
    sendRuntime(("%s hits: %s → %s (%d)"):format(short(author), cardLabel(c), handLabel(h.cards), tot))
    if tot > 21 then
      h.bust = true
      sendRuntime(("%s busts!"):format(short(author)))
    elseif tot == 21 then
      h.stood = true -- auto-stand on 21
    end
  else -- stand
    h.stood = true
    sendRuntime(("%s stands at %d."):format(short(author), handValue(h.cards)))
  end

  BJ.turnIndex = BJ.turnIndex + 1
  nextTurnOrDealer()
end

------------------------------------------------------------
-- Start guard with auto-unstick
------------------------------------------------------------
local function canStartNow()
  if BJ.active then
    if BJ.phase == "ended" or BJ.phase == "idle" then
      safeHardReset()
      return true
    end
    return false
  end
  if BJ.lobby and BJ.lobby.active then return false end
  return true
end

------------------------------------------------------------
-- Slash commands
--   /psybj                 → lobby for 5 (30s)
--   /psybj 3               → lobby for 3
--   /psybj solo            → solo quick hand
--   /psybj stop            → cancel current hand/lobby
--   /psybj reset           → force-clear stuck state
--   /psybj bet N           → set your bet (works during lobby or betting window)
--   /psybj bank            → print banks for seated players
--   /psybj highscores      → print top 8 peak banks
--   /psybj help            → brief help
------------------------------------------------------------
SLASH_PSYBJ1 = "/psybj"
SLASH_PSYBJ2 = "/psyblackjack"
SlashCmdList.PSYBJ = function(msg)
  msg = trim(msg or "")
  local a1, rest = msg:match("^(%S+)%s*(.*)$")
  a1 = (a1 or ""):lower()

  if msg == "" then
    if not canStartNow() then printLocal("A Blackjack hand is already running. Use /psybj reset if stuck."); return end
    openBlackjackLobby({ solo=false, maxPlayers=5, duration=30 })
    return
  end

  if a1 == "help" then
    printLocal("Blackjack: set bet in lobby with !bet N (default bet uses lobby stake or 10).")
    printLocal("Banks start at 100; Blackjack pays 3:2. Turn actions: hit/stand (h/s).")
    printLocal("Commands: /psybj, /psybj 3, /psybj solo, /psybj stop, /psybj reset, /psybj bet N, /psybj bank, /psybj highscores")
    return
  end

  if a1 == "stop" then
    if BJ.lobby and BJ.lobby.active then BJ.lobby:Stop("stopped")
    elseif BJ.active then endGame("stopped") else printLocal("No Blackjack running.") end
    return
  end

  if a1 == "reset" then
    safeHardReset()
    printLocal("Blackjack state reset. You can start again.")
    return
  end

  if a1 == "solo" then
    if not canStartNow() then printLocal("A Blackjack hand is already running. Use /psybj reset if stuck."); return end
    hardReset()
    local me = playerFull()
    ensureBank(me)
    BJ.players = { me }
    BJ.joinedSet[me] = true
    BJ.defaultBet = 10
    BJ.bets[me] = clampBet(me, BJ.defaultBet)
    startHand()
    return
  end

  if a1 == "bet" then
    if not (BJ.phase == "lobby" or BJ.phase == "betting") then
      printLocal("You can only set your bet during the lobby or the betting window.")
      return
    end
    local n = tonumber(rest)
    if not n then printLocal("Usage: /psybj bet <amount>"); return end
    local me = playerFull()
    ensureBank(me)
    local b = setBet(me, n)
    printLocal(("Your bet is set to %d."):format(b))
    if BJ.phase == "betting" then announceBetsLine() end
    return
  end

  if a1 == "bank" then announceBanks(true); return end
  if a1 == "highscores" or a1 == "hiscore" or a1 == "scores" then announceHighscores(); return end

  local n = tonumber(a1)
  if n then
    n = math.max(1, math.min(n, 5))
    if not canStartNow() then printLocal("A Blackjack hand is already running. Use /psybj reset if stuck."); return end
    openBlackjackLobby({ solo=(n==1), maxPlayers=n, duration=30 })
    return
  end

  printLocal("Usage: /psybj [players] | solo | stop | reset | bet N | bank | highscores | help")
end

------------------------------------------------------------
-- Event wiring (chat input)
-- (Never reads guild; runtime routes to instance/raid/party/emote)
------------------------------------------------------------
local EVENTS = {
  "CHAT_MSG_SAY","CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER",
  "CHAT_MSG_RAID","CHAT_MSG_RAID_LEADER",
  "CHAT_MSG_INSTANCE_CHAT","CHAT_MSG_INSTANCE_CHAT_LEADER",
  "CHAT_MSG_WHISPER",
}
for _,ev in ipairs(EVENTS) do f:RegisterEvent(ev) end

f:SetScript("OnEvent", function(_, event, ...)
  local msg, author = ...
  onChatMessage(event, msg or "", author or "")
end)
