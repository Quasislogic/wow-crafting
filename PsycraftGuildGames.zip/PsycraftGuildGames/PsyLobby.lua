-- PsyLobby.lua — generic lobby (bare + managed modes)
-- - Bare:    PsyLobby.Start(opts) → returns lobby; you feed chat via :OnChat(...)
-- - Managed: PsyLobby.StartManaged(opts) → lobby installs its own chat listeners & timers
-- Start-time blurbs: SAY (fallback EMOTE).
-- Runtime: RAID → INSTANCE_CHAT → PARTY → EMOTE (never SAY/GUILD).
-- No SavedVariables.

------------------------------------------------------------
-- Export ASAP (global module)
------------------------------------------------------------
local Lobby = {}
Lobby.__index = Lobby
_G.PsyLobby = Lobby

------------------------------------------------------------
-- Tiny timer wrapper (Classic/MoP friendly)
------------------------------------------------------------
local function NewTimer(delay, func)
  if C_Timer and C_Timer.NewTimer then return C_Timer.NewTimer(delay, func) end
  local t = { _cancelled = false }
  function t:Cancel() t._cancelled = true end
  C_Timer.After(delay, function() if not t._cancelled then func() end end)
  return t
end

------------------------------------------------------------
-- Utils
------------------------------------------------------------
local function short(full) return (full and full:match("^[^-]+")) or (full or "?") end

local function normalizedRealm()
  local r = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "UnknownRealm"
  return (r or "UnknownRealm"):gsub("%s+","")
end

local function playerFull()
  local n = (UnitName and UnitName("player")) or "Player"
  return n .. "-" .. normalizedRealm()
end

local function canUseSay()
  local a,b = IsInInstance and IsInInstance()
  -- Retail/Classic return values differ; if only 1 is returned, 'a' is boolean
  local inInstance = (b and a) or (a == true)
  return not inInstance
end

local function SendInitial(msg)
  return SendRuntime(msg)
end

local function SendRuntime(msg)
  if IsInRaid and IsInRaid() then SendChatMessage(msg, "RAID"); return end
  local inInst, itype = IsInInstance and IsInInstance()
  if inInst and (itype == "party" or itype == "pvp" or itype == "arena") then
    SendChatMessage(msg, "INSTANCE_CHAT"); return
  end
  if IsInGroup and IsInGroup() then SendChatMessage(msg, "PARTY"); return end
  SendChatMessage(msg, "EMOTE")
end

------------------------------------------------------------
-- Defaults
------------------------------------------------------------
local DEFAULTS = {
  host        = nil,          -- defaults to player
  solo        = false,
  maxPlayers  = 5,
  duration    = 30,           -- seconds until auto-close
  warnAt      = 10,           -- seconds before close to warn
  minPlayers  = nil,          -- defaults to 1 if solo else 2
  gameName    = "Game",       -- shown in blurbs ("started <gameName>")
  joinPtnPlain= "!play",      -- chat message to join (exact match, case-insensitive)
  joinPtnStake= "^!play%s+stake%s+(%d+)$", -- optional stake capture (number)
  allowStake  = true,         -- if false, stake is ignored/disabled
  maxStake    = 1000000,      -- clamp if stake is allowed

  -- Kickoff (post-close) behavior
  kickoffGap      = 0.75,     -- short quiet gap before countdown (seconds)
  kickoffCount    = 3,        -- 3..2..1..Go!
  kickoffTickSec  = 0.5,      -- each "second" advances every 0.5s

  -- Custom senders (optional)
  startFn     = nil,          -- function(msg)  -- for start-time blurbs
  runtimeFn   = nil,          -- function(msg)  -- for runtime messages

  -- Bare-mode integration (optional)
  joinMatcher = nil,          -- function(msg)-> (true,payload)|(false)
  canJoin     = nil,          -- function(lobby, full, payload)-> true | false, "reason"
  onJoin      = nil,          -- function(lobby, full, payload)
  onWarn      = nil,          -- function(lobby)
  onClose     = nil,          -- function(lobby)           -- called with lobby.players filled
  onCancel    = nil,          -- function(lobby, why)      -- "not_enough" | "stopped"
}

------------------------------------------------------------
-- Core constructor (shared)
------------------------------------------------------------
local function newLobby(opts)
  opts = opts or {}
  local self = setmetatable({}, Lobby)

  self.host        = opts.host or playerFull()
  self.solo        = not not opts.solo
  self.maxPlayers  = math.max(1, opts.maxPlayers or DEFAULTS.maxPlayers)
  self.duration    = math.max(1, opts.duration or DEFAULTS.duration)
  self.warnAt      = math.min(self.duration, opts.warnAt or DEFAULTS.warnAt)
  self.minPlayers  = opts.minPlayers or (self.solo and 1 or 2)

  self.gameName    = opts.gameName or DEFAULTS.gameName

  self.startSend   = opts.startFn   or SendInitial
  self.runtime     = opts.runtimeFn or SendRuntime

  self.joinMatcher = opts.joinMatcher or function(_) return false end
  self.canJoin     = opts.canJoin
  self.onJoin      = opts.onJoin
  self.onWarn      = opts.onWarn
  self.onClose     = opts.onClose or function() end
  self.onCancel    = opts.onCancel

  -- Kickoff config (gap + accelerated countdown) for successful closes
  self.kickoffGap     = (opts.kickoffGap     ~= nil) and tonumber(opts.kickoffGap)     or DEFAULTS.kickoffGap
  self.kickoffCount   = (opts.kickoffCount   ~= nil) and tonumber(opts.kickoffCount)   or DEFAULTS.kickoffCount
  self.kickoffTickSec = (opts.kickoffTickSec ~= nil) and tonumber(opts.kickoffTickSec) or DEFAULTS.kickoffTickSec

  self.players, self.joined, self.byShort = {}, {}, {}
  self.active      = true
  self._managed    = false
  self._frame      = nil
  self._warnTimer  = nil
  self._closeTimer = nil
  self._countdownT = nil

  -- optional stake lock (managed convenience)
  self._stakeEnabled = (opts.allowStake ~= false)
  self._stakeGold    = 0
  self._maxStake     = tonumber(opts.maxStake) or DEFAULTS.maxStake

  -- managed join patterns (defaults used only in managed mode)
  self._ptnPlain    = opts.joinPtnPlain or DEFAULTS.joinPtnPlain
  self._ptnStake    = (opts.joinPtnStake ~= nil) and opts.joinPtnStake or DEFAULTS.joinPtnStake

  return self
end

------------------------------------------------------------
-- Bare-mode Start (you feed chat lines via :OnChat)
------------------------------------------------------------
function Lobby.Start(opts)
  local self = newLobby(opts)

  -- warn timer
  if not self.solo and self.duration > self.warnAt then
    self._warnTimer = NewTimer(self.duration - self.warnAt, function()
      if not self.active then return end
      if self.onWarn then
        self.onWarn(self)
      else
        -- include join hint (from plain pattern)
        local joinHint = self._ptnPlain or DEFAULTS.joinPtnPlain
        self.runtime(("Lobby closing in %d seconds. Type %s to join."):format(self.warnAt, joinHint))
        self.runtime("Waiting: " .. self:PlayersListString())
      end
    end)
  end

  -- close timer
  self._closeTimer = NewTimer(self.duration, function()
    if not self.active then return end
    if #self.players < (self.minPlayers or 2) then
      self:Stop("not_enough")
    else
      self:Close()
    end
  end)

  return self
end

------------------------------------------------------------
-- Managed-mode Start: self-handled chat + timers (+optional stake)
------------------------------------------------------------
-- Extra opts honored:
--   gameName, joinPtnPlain, joinPtnStake, allowStake, maxStake
function Lobby.StartManaged(opts)
  local self = Lobby.Start(opts) -- build timers as in bare
  self._managed = true

  local ptnPlain = self._ptnPlain or DEFAULTS.joinPtnPlain
  local ptnStake = self._ptnStake  -- can be nil to disable stake syntax

  -- Managed join matcher
  self.joinMatcher = function(msg)
    local m = (msg or ""):lower():gsub("%s+"," ")
    if m == (ptnPlain or ""):lower() then return true, nil end
    if ptnStake then
      local stake = m:match(ptnStake)
      if stake then return true, { stake = tonumber(stake) } end
    end
    return false
  end

  -- Default canJoin with stake lock (only if stake is allowed)
  if not self.canJoin then
    self.canJoin = function(lobby, full, payload)
      if not lobby._stakeEnabled then return true end
      if payload and payload.stake and payload.stake > 0 then
        local stake = math.min(payload.stake, lobby._maxStake)
        if lobby._stakeGold == 0 then
          lobby._stakeGold = stake
          lobby.runtime(("Stake set to %dg by %s."):format(stake, short(full)))
          return true
        else
          if stake ~= lobby._stakeGold then
            return false, ("Stake is %dg. Join with: !Play stake %d"):format(lobby._stakeGold, lobby._stakeGold)
          end
        end
      else
        if lobby._stakeGold > 0 then
          return false, ("Stake is %dg. Join with: !Play stake %d"):format(lobby._stakeGold, lobby._stakeGold)
        end
      end
      return true
    end
  end

  -- Event frame to consume chat lines automatically
  local f = CreateFrame("Frame")
  self._frame = f
  local EVTS = {
    "CHAT_MSG_SAY","CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID","CHAT_MSG_RAID_LEADER",
    "CHAT_MSG_INSTANCE_CHAT","CHAT_MSG_INSTANCE_CHAT_LEADER","CHAT_MSG_WHISPER"
  }
  for _,e in ipairs(EVTS) do f:RegisterEvent(e) end

  f:SetScript("OnEvent", function(_, _, msg, author)
    if not self.active then return end
    local aName, aRealm = strsplit("-", author or "")
    if not aRealm or aRealm == "" then author = (aName or "?") .. "-" .. normalizedRealm() end
    self:OnChat(msg or "", author)
  end)

  -- Initial blurbs (start-time)
  local joinHint = ptnPlain or DEFAULTS.joinPtnPlain
  local line1
  if self._stakeEnabled and self._stakeGold > 0 then
    line1 = ("%s started %s — type %s to join (max %d). Stake: %dg."):
      format(short(self.host), self.gameName, joinHint, self.maxPlayers, self._stakeGold)
  else
    line1 = ("%s started %s — type %s to join (max %d)."):
      format(short(self.host), self.gameName, joinHint, self.maxPlayers)
  end
  self.startSend(line1)

  if not self.solo then
    self.startSend(("Lobby will close in %d seconds or when full."):format(self.duration))
  else
    self.startSend(("Solo %s — first %s joins; others cannot join."):format(self.gameName, joinHint))
  end
  
  -- When lobby closes/cancels, stop listening
  local origClose = self.onClose
  self.onClose = function(lob)
    if self._frame then self._frame:UnregisterAllEvents(); self._frame:SetScript("OnEvent", nil) end
    origClose(lob)
  end
  local origCancel = self.onCancel
  self.onCancel = function(lob, why)
    if self._frame then self._frame:UnregisterAllEvents(); self._frame:SetScript("OnEvent", nil) end
    if origCancel then origCancel(lob, why) end
  end

  return self
end

------------------------------------------------------------
-- Public methods (both modes)
------------------------------------------------------------
function Lobby:Stop(reason)
  if not self.active then return end
  self.active = false
  if self._warnTimer  then self._warnTimer:Cancel()  end
  if self._closeTimer then self._closeTimer:Cancel() end
  if self._countdownT then self._countdownT:Cancel() end
  if self._frame then self._frame:UnregisterAllEvents(); self._frame:SetScript("OnEvent", nil) end
  if self.onCancel then self.onCancel(self, reason or "stopped") end
end

-- Successful close → quiet gap → wait → onClose()
function Lobby:Close()
  if not self.active then return end
  self.active = false
  if self._warnTimer  then self._warnTimer:Cancel()  end
  if self._closeTimer then self._closeTimer:Cancel() end
  if self._frame then self._frame:UnregisterAllEvents(); self._frame:SetScript("OnEvent", nil) end

  self.runtime("Lobby closed.")

  local gap     = math.max(0, tonumber(self.kickoffGap) or DEFAULTS.kickoffGap)
  local count   = math.max(0, tonumber(self.kickoffCount) or DEFAULTS.kickoffCount)
  local tickSec = math.max(0.05, tonumber(self.kickoffTickSec) or DEFAULTS.kickoffTickSec)

  -- Total wait time = gap + (count * tickSec)
  local totalDelay = gap + (count * tickSec)

  if totalDelay <= 0 then
    self.onClose(self)
    return
  end

  -- Single "Starting..." message
  self.runtime("Starting...")

  -- Wait, then run onClose
  self._countdownT = NewTimer(totalDelay, function()
    self.onClose(self)
  end)
end


function Lobby:AddPlayer(full, payload)
  if not self.active then return end
  if self.joined[full] then return end

  if self.solo and #self.players >= 1 then
    self.runtime(("Solo lobby: only one player allowed. %s cannot join."):format(short(full)))
    return
  end
  if #self.players >= self.maxPlayers then
    self.runtime("Lobby is full.")
    return
  end

  if self.canJoin then
    local ok, why = self.canJoin(self, full, payload)
    if not ok then
      if why and why ~= "" then self.runtime(why) end
      return
    end
  end

  table.insert(self.players, full)
  self.joined[full] = true
  self.byShort[short(full):lower()] = full
  if self.onJoin then self.onJoin(self, full, payload) end

  self.runtime(("%s has joined (%d/%d)."):format(short(full), #self.players, self.maxPlayers))
  self.runtime("Waiting: " .. self:PlayersListString())

  -- auto-close when filled or solo first join (triggers countdown path)
  if (self.solo and #self.players == 1) or (#self.players >= self.maxPlayers) then
    self:Close()
  end
end

-- Feed a chat line to the lobby (used by bare mode; managed mode does this internally)
function Lobby:OnChat(msg, authorFull)
  if not self.active then return end
  local ok, payload = self.joinMatcher(msg or "")
  if ok then self:AddPlayer(authorFull, payload) end
end

function Lobby:PlayersListString()
  local names = {}
  for i,full in ipairs(self.players) do names[i] = short(full) end
  return (#names > 0) and table.concat(names, ", ") or "—"
end

-- Optional: convenience to send start blurbs (bare mode)
function Lobby:StartBlurb(msg) if msg and msg ~= "" then self.startSend(msg) end end
function Lobby:StartBlurbLines(lines) for _,m in ipairs(lines or {}) do if m and m ~= "" then self.startSend(m) end end end
