-- PsyQuizPackLoader.lua
-- Registers any data-only quiz packs that append to _G.PsyQuiz_Quizzes

local registered = false

local function registerAllPacks()
  if registered then return end
  if not (_G.PsyQuiz and _G.PsyQuiz.Register) then return end

  local packs = rawget(_G, "PsyQuiz_Quizzes")
  if type(packs) ~= "table" then return end

  local total = 0
  for _, group in ipairs(packs) do
    -- each "group" is an array of quizzes
    if type(group) == "table" then
      for _, quiz in ipairs(group) do
        if quiz and quiz.name and quiz.qs then
          -- Register(name, qs[, diff]) — diff is optional if your core supports it
          if type(_G.PsyQuiz.Register) == "function" then
            _G.PsyQuiz.Register(quiz.name, quiz.qs, quiz.diff)
            total = total + 1
          end
        end
      end
    end
  end

  if total > 0 then
    print(string.format("|cff00ff88[PsyQuiz]|r Registered %d quiz(es) from packs.", total))
  end

  -- prevent re-registering on future events
  registered = true
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
  registerAllPacks()
end)
