-- PsyQuiz.lua — modular quiz with registry + selection, built on PsyLobby (Managed)
-- Requires: PsyLobby.lua exporting _G.PsyLobby with StartManaged()
-- No SavedVariables. All in-memory.

local ADDON = "PsyQuiz"
local f = CreateFrame("Frame")

------------------------------------------------------------
-- Utils
------------------------------------------------------------
local function trim(s) return (s or ""):gsub("^%s+",""):gsub("%s+$","") end
local function short(full) return (full and full:match("^[^-]+")) or (full or "?") end

local function normalizedRealm()
  local r = (GetNormalizedRealmName and GetNormalizedRealmName()) or (GetRealmName and GetRealmName()) or "UnknownRealm"
  return (r or "UnknownRealm"):gsub("%s+","")
end
local function playerFull()
  local n = (UnitName and UnitName("player")) or "Player"
  return n .. "-" .. normalizedRealm()
end

local function printLocal(msg) print(string.format("|cff00ff88[%s]|r %s", ADDON, msg)) end

-- Timer helper (Classic/MoP friendly)
local function NewTimer(delay, fn)
  if C_Timer and C_Timer.NewTimer then return C_Timer.NewTimer(delay, fn) end
  local t = { _cancelled=false }
  function t:Cancel() self._cancelled=true end
  C_Timer.After(delay, function() if not t._cancelled then fn() end end)
  return t
end

-- === SFX =====================================================================
-- Drop your audio files into your addon folder and update these paths if needed.
local SFX = {
  select  = "Interface\\AddOns\\PsycraftGuildGames\\media\\FinalAnswer.mp3",
  correct = "Interface\\AddOns\\PsycraftGuildGames\\media\\Win.mp3",
  wrong   = "Interface\\AddOns\\PsycraftGuildGames\\media\\Lose.mp3",
}
local function PlaySFX(path) if path and path ~= "" then PlaySoundFile(path, "Master") end end

------------------------------------------------------------
-- Chat routing
-- Start-time blurbs: SAY (fallback EMOTE)
-- Runtime: INSTANCE → RAID → PARTY → EMOTE (never SAY/GUILD)
------------------------------------------------------------
local function sendStart(msg)
  local inInstance = IsInInstance and IsInInstance()
  if inInstance then SendChatMessage(msg, "EMOTE") else SendChatMessage(msg, "SAY") end
end
local function sendRuntime(msg)
  if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE) then
    SendChatMessage(msg, "INSTANCE_CHAT"); return
  end
  if IsInRaid and IsInRaid() then SendChatMessage(msg, "RAID"); return end
  if IsInGroup and IsInGroup() then SendChatMessage(msg, "PARTY"); return end
  SendChatMessage(msg, "EMOTE")
end
local function runtimeChannel()
  if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE) then
    return "INSTANCE_CHAT"
  end
  if IsInRaid and IsInRaid() then return "RAID" end
  if IsInGroup and IsInGroup() then return "PARTY" end
  return "EMOTE"
end

------------------------------------------------------------
-- Registry + Module state / API
------------------------------------------------------------
local QUIZ = {
  registry   = {},   -- array of { id, name, questions }
  byName     = {},   -- lower(name) -> id
  byId       = {},   -- id -> index in registry
  nextID     = 1,

  selectedId = nil,  -- current selection (id)

  lobby      = nil,
  active     = false,
  phase      = "idle",      -- idle | lobby | running | ended
  host       = nil,

  players    = {},          -- array of full names
  joinedSet  = {},          -- full -> true
  byShort    = {},          -- short-name -> full

  qtime      = 10,          -- seconds per question (default 10s)
  qcount     = 10,          -- how many to ask (overridden to "all" when omitted at start)
  idx        = 0,           -- current q index
  timer      = nil,         -- per-question timer
  gapTimer   = nil,         -- inter-question gap (post-reveal)
  gap        = 2,           -- quiet pause between questions
  reveal     = 1.0,         -- pause to show green correct UI before progressing

  scores     = {},          -- host: full->int ; client mirror: short->int
  answered   = {},          -- per-question: full -> true
  accepting  = false,       -- accepting answers now?

  correctSet   = {},        -- full -> true
  correctOrder = {},        -- array of short names in answer order

  -- Local-player per-question state for SFX
  meAnsweredIdx = nil,      -- 1..4 if we selected, else nil
  meWasCorrect  = false,    -- true if our answer was correct
}

local function setHost(fullname) QUIZ.host = fullname end
local function amHost() return QUIZ.host == playerFull() end

local function normalizeQuiz(questions)
  local ok = type(questions) == "table" and #questions > 0
  if not ok then return nil end
  for _,q in ipairs(questions) do
    if type(q) ~= "table" or type(q.q) ~= "string" or type(q.choices) ~= "table" or type(q.correct) ~= "number" then
      return nil
    end
  end
  return questions
end

local function findQuizByNameOrId(arg)
  if not arg or arg == "" then return nil end
  local id = tonumber(arg)
  if id and QUIZ.byId[id] then return id end

  local needle = arg:lower()
  local exact = QUIZ.byName[needle]
  if exact then return exact end

  local bestId, bestLen = nil, 1e9
  for _,entry in ipairs(QUIZ.registry) do
    local nm = entry.name:lower()
    if nm:find(needle, 1, true) then
      if #nm < bestLen then bestId, bestLen = entry.id, #nm end
    end
  end
  return bestId
end

local function ensureSelectedOrDefault()
  if QUIZ.selectedId and QUIZ.byId[QUIZ.selectedId] then return QUIZ.selectedId end
  if #QUIZ.registry > 0 then
    QUIZ.selectedId = QUIZ.registry[1].id
    return QUIZ.selectedId
  end
  return nil
end

-- Public API
_G.PsyQuiz = {
  Register = function(name, questions)
    name = tostring(name or ""):gsub("^%s+",""):gsub("%s+$","")
    if name == "" then return nil, "empty-name" end
    local q = normalizeQuiz(questions); if not q then return nil, "bad-questions" end
    local id = QUIZ.nextID; QUIZ.nextID = QUIZ.nextID + 1
    local entry = { id = id, name = name, questions = q }
    table.insert(QUIZ.registry, entry)
    QUIZ.byName[name:lower()] = id
    QUIZ.byId[id] = #QUIZ.registry
    if not QUIZ.selectedId then QUIZ.selectedId = id end
    return id
  end,

  GetQuizzes = function()
    local t = {}
    for _,e in ipairs(QUIZ.registry) do
      t[#t+1] = { id=e.id, name=e.name, count=#(e.questions or {}) }
    end
    table.sort(t, function(a,b) return (a.id or 0) < (b.id or 0) end)
    return t
  end,

  Select = function(nameOrId)
    local id = findQuizByNameOrId(nameOrId)
    if not id then return nil, "not-found" end
    QUIZ.selectedId = id
    return id
  end,

  GetScoreboard = function()
    local t = {}
    for full,score in pairs(QUIZ.scores) do
      t[#t+1] = { full = full, short = short(full), score = score }
    end
    table.sort(t, function(a,b) return (a.score or 0) > (b.score or 0) end)
    return t
  end,

  IsRunning = function() return QUIZ.active and QUIZ.phase == "running" end,
}

------------------------------------------------------------
-- Scores → UI bridge
------------------------------------------------------------
local function pushScoresToUI()
  local UI = _G.PsyQuizUI
  if not (UI and UI.SetScores) then return end

  local arr = {}
  -- Build display array from whatever we have:
  -- Host stores full->int; clients store short->int (mirror).
  for k, sc in pairs(QUIZ.scores) do
    local name = k
    if name:find("-", 1, true) then name = short(name) end
    arr[#arr+1] = { name = name, score = sc or 0 }
  end
  table.sort(arr, function(a,b)
    if a.score ~= b.score then return a.score > b.score end
    return (a.name or "") < (b.name or "")
  end)

  UI.SetScores(arr)
  if UI.ShowScores then UI.ShowScores(true) end
end

-- Host → clients: send compact scores "Name:Score;Name:Score;..."
local function netChannel()
  if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) or IsInRaid(LE_PARTY_CATEGORY_INSTANCE) then
    return "INSTANCE_CHAT"
  end
  if IsInRaid and IsInRaid() then return "RAID" end
  if IsInGroup and IsInGroup() then return "PARTY" end
  return nil
end

local PREFIX = "PsyQuiz"
if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
  C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
end

local function broadcastScores()
  local ch = netChannel()
  if not ch or not C_ChatInfo then return end
  local sb = _G.PsyQuiz.GetScoreboard()
  local parts = {}
  local maxN = 40
  for i, row in ipairs(sb) do
    parts[#parts+1] = string.format("%s:%d", row.short or "?", row.score or 0)
    if i >= maxN then break end
  end
  C_ChatInfo.SendAddonMessage(PREFIX, "SCORES\t" .. table.concat(parts, ";"), ch)
end

------------------------------------------------------------
-- === Net sync (UI mirror + handshake) ====================
------------------------------------------------------------
local function NetSend(kind, ...)
  local ch = netChannel()
  if not (C_ChatInfo and ch) then return end
  local parts = { tostring(kind) }
  for i=1, select("#", ...) do
    local v = tostring(select(i, ...) or "")
    v = v:gsub("[\r\n]", " ")
    parts[#parts+1] = v
  end
  C_ChatInfo.SendAddonMessage(PREFIX, table.concat(parts, "\t"), ch)
end

local function NetWhisper(kind, target, ...)
  if not (C_ChatInfo and target and target ~= "") then return end
  local parts = { tostring(kind) }
  for i=1, select("#", ...) do
    local v = tostring(select(i, ...) or "")
    v = v:gsub("[\r\n]", " ")
    parts[#parts+1] = v
  end
  C_ChatInfo.SendAddonMessage(PREFIX, table.concat(parts, "\t"), "WHISPER", target)
end

-- Handshake (host-side counters)
local Handshake = { expecting=false, readyCount=0, timer=nil }
local function HandshakeReset()
  Handshake.expecting = false
  Handshake.readyCount = 0
  if Handshake.timer then Handshake.timer:Cancel() end
  Handshake.timer = nil
end

-- Host-authoritative, client-mirror gate
local function NetOnAddonMsg(prefix, msg, channel, sender)
  if prefix ~= PREFIX then return end

  local parts = {}
  for field in string.gmatch(msg, "([^\t]+)") do parts[#parts+1] = field end
  local kind = parts[1] or ""
  local me   = playerFull()
  local function fromHost() return sender == (QUIZ.host or "") end
  local iAmHost = amHost()

  if kind == "QUIZ_START" then
    -- Clients learn host and ACK; host ignores.
    if sender ~= me then
      setHost(sender)
      wipe(QUIZ.scores)
      pushScoresToUI()
      if _G.PsyQuizUI and _G.PsyQuizUI.ShowScores then _G.PsyQuizUI.ShowScores(true) end
      NetWhisper("QUIZ_READY", sender)
      printLocal(("Quiz starting by %s — %s (%ds, %s qs)"):format(
        short(sender or "?"), (parts[4] or "Quiz"), tonumber(parts[2] or 0) or 0, parts[3] or "?"))
    end
    return
  end

  if kind == "QUIZ_READY" then
    if Handshake.expecting and iAmHost then
      Handshake.readyCount = Handshake.readyCount + 1
    end
    return
  end

  if kind == "START" then
    if sender ~= me then setHost(sender) end
    return
  end

  -- From here: only process SHOW/REVEAL/SCORES/END if it came from host and we are not host.
  if iAmHost or not fromHost() then return end

  if kind == "SHOW" then
    -- parts: 1=SHOW, 2=idx, 3=qtime, 4=q, 5..8=choices
    local qtext   = parts[4] or "?"
    local choices = { parts[5] or "", parts[6] or "", parts[7] or "", parts[8] or "" }
    if _G.PsyQuizUI and _G.PsyQuizUI.Show then
      _G.PsyQuizUI.Show(qtext, choices, function(i)
        PlaySFX(SFX.select)
        local map = { "A","B","C","D" }
        local ch  = runtimeChannel()
        if map[i] then SendChatMessage(map[i], ch) end
      end, "|cff80c0ffPsyQuiz|r", tonumber(parts[3]) or 0)
      if _G.PsyQuizUI.ShowScores then _G.PsyQuizUI.ShowScores(true) end
      pushScoresToUI()
      if _G.PsyQuizUI.StartTimer then
        _G.PsyQuizUI.StartTimer(tonumber(parts[3]) or 0)
      end
    end
    return
  end

  if kind == "REVEAL" then
    local correct = tonumber(parts[2]) or 1
    local hold    = tonumber(parts[3]) or 0
    if _G.PsyQuizUI and _G.PsyQuizUI.RevealCorrect then
      _G.PsyQuizUI.RevealCorrect(correct, nil, hold)
    end
    return
  end

  if kind == "SCORES" then
    local payload = parts[2] or ""
    wipe(QUIZ.scores)
    for pair in string.gmatch(payload, "([^;]+)") do
      local name, sc = pair:match("^([^:]+):(%-?%d+)$")
      if name and sc then
        QUIZ.scores[name] = tonumber(sc) or 0   -- client mirror short->int
      end
    end
    pushScoresToUI()
    return
  end

  if kind == "END" then
    if _G.PsyQuizUI and _G.PsyQuizUI.Hide then _G.PsyQuizUI.Hide() end
    return
  end
end

------------------------------------------------------------
-- === Optional: Single-host lock (party/raid) =============
------------------------------------------------------------
local HOST_PREFIX = "PsyQuizHost"
if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
  C_ChatInfo.RegisterAddonMessagePrefix(HOST_PREFIX)
end

local HostLock = {
  holder = nil,
  since  = 0,
  ttl    = 12,
  beat   = 4,
  timer  = nil,
}

local function HostNetSend(kind, payload)
  local ch = netChannel()
  if not ch or not C_ChatInfo then return end
  C_ChatInfo.SendAddonMessage(HOST_PREFIX, kind .. "\t" .. (payload or ""), ch)
end

local function HostStartHeartbeat()
  if HostLock.timer then HostLock.timer:Cancel() end
  HostLock.timer = C_Timer.NewTicker(HostLock.beat, function()
    HostNetSend("BEAT", playerFull())
  end)
end

local function HostStopHeartbeat()
  if HostLock.timer then HostLock.timer:Cancel() end
  HostLock.timer = nil
end

local function HostTryLock()
  local now = GetTime()
  if not HostLock.holder or (now - HostLock.since) > HostLock.ttl then
    HostLock.holder = playerFull()
    HostLock.since  = now
    HostNetSend("LOCK", HostLock.holder)
    HostStartHeartbeat()
    return true
  end
  return HostLock.holder == playerFull()
end

local function HostRelease()
  if HostLock.holder == playerFull() then
    HostNetSend("UNLOCK", HostLock.holder)
    HostLock.holder = nil
    HostStopHeartbeat()
  end
end

local function OnHostAddonMsg(prefix, msg, channel, sender)
  if prefix ~= HOST_PREFIX then return end
  local kind, who = msg:match("^([^\t]+)\t?(.*)$")
  local now = GetTime()
  if kind == "LOCK" then
    if HostLock.holder ~= playerFull() then
      HostLock.holder = who ~= "" and who or sender
      HostLock.since  = now
    end
  elseif kind == "BEAT" then
    if HostLock.holder == (who ~= "" and who or sender) then
      HostLock.since = now
    end
  elseif kind == "UNLOCK" then
    if HostLock.holder == (who ~= "" and who or sender) then
      HostLock.holder = nil
      HostLock.since  = 0
    end
  end
end

------------------------------------------------------------
-- Quiz engine helpers
------------------------------------------------------------
local function clearTimer() if QUIZ.timer then QUIZ.timer:Cancel() end; QUIZ.timer=nil end
local function clearGapTimer() if QUIZ.gapTimer then QUIZ.gapTimer:Cancel() end; QUIZ.gapTimer=nil end

local _lastScoreAnnounce = nil

local function resetQuizState()
  clearTimer(); clearGapTimer()
  QUIZ.active = false
  QUIZ.phase = "idle"
  QUIZ.host = nil
  wipe(QUIZ.players); wipe(QUIZ.joinedSet); wipe(QUIZ.byShort)
  QUIZ.qtime = QUIZ.qtime or 10
  QUIZ.qcount = 10
  QUIZ.idx = 0
  QUIZ.accepting = false
  wipe(QUIZ.scores); wipe(QUIZ.answered)
  wipe(QUIZ.correctSet); wipe(QUIZ.correctOrder)
  QUIZ.meAnsweredIdx = nil
  QUIZ.meWasCorrect  = false
  _lastScoreAnnounce = nil
  if QUIZ.lobby and QUIZ.lobby.active then QUIZ.lobby:Stop("reset") end
  QUIZ.lobby = nil
  pushScoresToUI()
end

local function announceScoreboard()
  local sb = _G.PsyQuiz.GetScoreboard()
  if #sb == 0 then
    sendRuntime("Scoreboard: —")
    wipe(QUIZ.scores); pushScoresToUI()
    return
  end
  local parts = {}
  for i, row in ipairs(sb) do
    parts[#parts+1] = string.format("%s:%d", row.short, row.score or 0)
    if i >= 8 then break end
  end
  local payload = table.concat(parts, "  ")
  if payload ~= _lastScoreAnnounce then
    sendRuntime("Scoreboard: " .. payload)
    _lastScoreAnnounce = payload
  end
  pushScoresToUI()
  if amHost() then broadcastScores() end
end

-- PRESENT QUESTION: prints to chat for everyone + pops local UI for addon users
local function getSelectedQuestions()
  local id = ensureSelectedOrDefault()
  if not id then return {} end
  local idx = QUIZ.byId[id]
  local entry = idx and QUIZ.registry[idx]
  return (entry and entry.questions) or {}
end

local function presentQuestion(qobj)
  -- reset per-question local flags
  QUIZ.meAnsweredIdx = nil
  QUIZ.meWasCorrect  = false

  local lines = {}
  lines[1] = string.format("Q%d: %s", QUIZ.idx, qobj.q or "?")
  local lbl = {"A","B","C","D","E","F","G","H"}
  for i,choice in ipairs(qobj.choices or {}) do
    lines[#lines+1] = string.format("  %s) %s", lbl[i] or tostring(i), choice)
  end
  lines[#lines+1] = string.format("Answer with A/B/C/D (or 1/2/3/4). %ds timer.", QUIZ.qtime)
  for _,m in ipairs(lines) do sendRuntime(m) end

  -- Local clickable UI (does not change network flow; just sends A/B/C/D)
  if _G.PsyQuizUI and _G.PsyQuizUI.Show then
    _G.PsyQuizUI.Show(
      qobj.q,
      qobj.choices,
      function(i)
        PlaySFX(SFX.select)
        QUIZ.meAnsweredIdx = i
        local map = {"A","B","C","D","E","F","G","H"}
        local ch  = runtimeChannel()
        if map[i] then SendChatMessage(map[i], ch) end
      end,
      "|cff80c0ffPsyQuiz|r",
      QUIZ.qtime
    )
    pushScoresToUI()
  end

  -- Broadcast question to other clients to mirror UI (host only)
  if amHost() then
    NetSend("SHOW",
      tostring(QUIZ.idx or 1),
      tostring(QUIZ.qtime or 10),
      qobj.q or "?",
      (qobj.choices and qobj.choices[1]) or "",
      (qobj.choices and qobj.choices[2]) or "",
      (qobj.choices and qobj.choices[3]) or "",
      (qobj.choices and qobj.choices[4]) or ""
    )
  end
end

local function endQuiz(reason)
  QUIZ.phase = "ended"
  QUIZ.active = false
  clearTimer(); clearGapTimer()

  if _G.PsyQuizUI and _G.PsyQuizUI.Hide then _G.PsyQuizUI.Hide() end
  StopMusic()

  -- notify clients & release host lock
  if amHost() then NetSend("END") end
  HostRelease()
  HandshakeReset()

  if reason ~= "stopped" then
    sendRuntime("Quiz finished!")
    announceScoreboard()
  else
    sendRuntime("Quiz cancelled.")
  end
  resetQuizState()
end

local function endQuestionReveal(qobj)
  -- === compute correctness first (so SFX syncs with the reveal image) ===
  if QUIZ.meAnsweredIdx and (qobj.correct or -1) == QUIZ.meAnsweredIdx then
    QUIZ.meWasCorrect = true
  else
    QUIZ.meWasCorrect = false
  end

  -- 1) Reveal end-state UI (correct + my pick), without closing the frame yet.
  local revealUsed = 0
  if _G.PsyQuizUI and _G.PsyQuizUI.RevealCorrect then
    local d = tonumber(QUIZ.reveal) or 0
    local myPick = QUIZ.meAnsweredIdx -- 1..4 or nil
    if d > 0 then
      _G.PsyQuizUI.RevealCorrect(qobj.correct or 1, myPick, d)
      revealUsed = d
    else
      _G.PsyQuizUI.RevealCorrect(qobj.correct or 1, myPick, 0)
    end
  end

  -- === play SFX right after the reveal image swaps ===
  if QUIZ.meAnsweredIdx then
    if QUIZ.meWasCorrect then PlaySFX(SFX.correct) else PlaySFX(SFX.wrong) end
  end

  -- Mirror reveal timing to other clients (host only)
  if amHost() then
    local d = tonumber(QUIZ.reveal) or 0
    NetSend("REVEAL", tostring(qobj.correct or 1), tostring(d))
  end

  -- 2) Announce results (then scoreboard/panel updates after)
  local winners = (#QUIZ.correctOrder > 0) and table.concat(QUIZ.correctOrder, ", ") or "No one"
  local correctLabel = ({"A","B","C","D","E","F","G","H"})[(qobj.correct or 1)] or tostring(qobj.correct or 1)
  sendRuntime(("Time! Correct answer was %s — Winners: %s."):format(correctLabel, winners))
  announceScoreboard()

  -- 3) Decide whether to end or proceed
  local pool = getSelectedQuestions()
  local total = math.min(QUIZ.qcount or #pool, #pool)
  if QUIZ.idx >= total or total == 0 then
    clearGapTimer()
    QUIZ.gapTimer = NewTimer(revealUsed, function() endQuiz("done") end)
    return
  end

  -- 4) After reveal pause + QUIZ.gap, advance to next question
  clearGapTimer()
  local wait = (revealUsed) + (QUIZ.gap or 0)
  QUIZ.accepting = false
  local function proceedNext()
    wipe(QUIZ.answered); wipe(QUIZ.correctSet); wipe(QUIZ.correctOrder)
    QUIZ.idx = QUIZ.idx + 1
    local q2 = getSelectedQuestions()[QUIZ.idx]
    if not q2 then endQuiz("done"); return end
    QUIZ.accepting = true
    presentQuestion(q2)
    clearTimer()
    QUIZ.timer = NewTimer(QUIZ.qtime, function()
      if not QUIZ.accepting then return end
      QUIZ.accepting = false
      endQuestionReveal(q2)
    end)
  end
  if wait <= 0 then proceedNext() else QUIZ.gapTimer = NewTimer(wait, proceedNext) end
end

local function startQuizRun()
  QUIZ.phase = "running"
  QUIZ.active = true
  setHost(playerFull())  -- authoritative host
  QUIZ.idx = 0
  wipe(QUIZ.scores); wipe(QUIZ.answered); wipe(QUIZ.correctSet); wipe(QUIZ.correctOrder)
  QUIZ.meAnsweredIdx = nil
  QUIZ.meWasCorrect  = false

  local pool = getSelectedQuestions()
  if #pool == 0 then
    sendRuntime("No questions in the selected quiz.")
    resetQuizState()
    return
  end

  if not QUIZ._runQCountExplicit then
    QUIZ.qcount = #pool
  end

  -- Music: play intro then tension after N seconds
  PlayMusic("Interface\\AddOns\\PsycraftGuildGames\\media\\LetsPlay.mp3")
  C_Timer.After(8, function()
    PlayMusic("Interface\\AddOns\\PsycraftGuildGames\\media\\quiztension.mp3")
  end)

  -- fresh (empty) scores panel visible at start
  pushScoresToUI()

  -- Tell clients quiz is starting (UI hint only)
  NetSend("START", tostring(QUIZ.selectedId or 0))

  QUIZ.idx = 1
  local q1 = pool[QUIZ.idx]
  QUIZ.accepting = true
  presentQuestion(q1)
  clearTimer()
  QUIZ.timer = NewTimer(QUIZ.qtime, function()
    if not QUIZ.accepting then return end
    QUIZ.accepting = false
    endQuestionReveal(q1)
  end)
end

------------------------------------------------------------
-- Accept answers during quiz (single attempt per player per question)
------------------------------------------------------------
local function onChatMessage(event, msg, author)
  if not (QUIZ.active and QUIZ.phase == "running" and QUIZ.accepting) then return end
  if not msg or msg == "" then return end

  -- Normalize sender to FullName-Realm
  local aName, aRealm = strsplit("-", author or "")
  if not aRealm or aRealm == "" then author = (aName or "?") .. "-" .. normalizedRealm() end
  if not QUIZ.joinedSet[author] then return end  -- only players may answer

  local pool = getSelectedQuestions()
  local q = pool and pool[QUIZ.idx]
  if not q then return end

  local guess = trim(msg):lower()
  local function normalizeAnswer(m)
    if m == "a" or m == "1" then return 1 end
    if m == "b" or m == "2" then return 2 end
    if m == "c" or m == "3" then return 3 end
    if m == "d" or m == "4" then return 4 end
    if m == "e" or m == "5" then return 5 end
    if m == "f" or m == "6" then return 6 end
    if m == "g" or m == "7" then return 7 end
    if m == "h" or m == "8" then return 8 end
    return nil
  end
  local ans = normalizeAnswer(guess)
  if not ans then return end

  -- one attempt per player per question
  if QUIZ.answered[author] then return end
  QUIZ.answered[author] = true

  -- If this was YOU answering via chat (not UI), play the select sfx once and remember pick
  local me = playerFull()
  if author == me then
    if not QUIZ.meAnsweredIdx then PlaySFX(SFX.select) end
    QUIZ.meAnsweredIdx = QUIZ.meAnsweredIdx or ans
  end

  -- If correct: record & score (UI update deferred until reveal/announce)
  if ans == (q.correct or -1) then
    if not QUIZ.correctSet[author] then
      QUIZ.correctSet[author] = true
      table.insert(QUIZ.correctOrder, short(author))
      QUIZ.scores[author] = (QUIZ.scores[author] or 0) + 1
    end
    if author == me then
      QUIZ.meWasCorrect = true
    end
  end
end

------------------------------------------------------------
-- Managed lobby bootstrap
------------------------------------------------------------
local function openQuizLobby(opts)
  resetQuizState()
  QUIZ.phase = "lobby"
  QUIZ.host  = playerFull()

  -- Optional: leader-only gate (comment out to allow anyone)
  --[[
  if (IsInGroup() or IsInRaid()) and not (UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")) then
    printLocal("Only group leader/assist can start a quiz.")
    return
  end
  ]]

  -- Optional: single-host lock in group
  if IsInGroup() or IsInRaid() then
    if not HostTryLock() then
      local holder = HostLock.holder or "someone else"
      printLocal(("A quiz host is already active: %s"):format(holder))
      return
    end
  end

  -- Apply run settings
  QUIZ.qtime  = math.max(3, tonumber(opts.qtime) or QUIZ.qtime or 10)
  QUIZ.qcount = tonumber(opts.qcount) or QUIZ.qcount
  QUIZ._runQCountExplicit = opts.qcount ~= nil

  local entry = QUIZ.registry[ QUIZ.byId[ ensureSelectedOrDefault() ] ]
  local quizName = entry and entry.name or "Quiz"

  -- Handshake: announce upcoming quiz so clients prep and ACK
  HandshakeReset()
  Handshake.expecting = true
  NetSend("QUIZ_START", tostring(QUIZ.qtime or 10), tostring(QUIZ.qcount or 0), quizName or "Quiz")
  Handshake.timer = C_Timer.NewTimer(2.0, function()
    printLocal(("Addon clients ready: %d"):format(Handshake.readyCount or 0))
    Handshake.expecting = false
  end)

  QUIZ.lobby = PsyLobby.StartManaged({
    gameName     = "Quiz",
    joinPtnPlain = "!play",
    joinPtnStake = nil,
    allowStake   = false,

    solo       = opts.solo or false,
    maxPlayers = opts.maxPlayers or 5,
    duration   = opts.duration or 30,
    warnAt     = 10,

    startFn   = function(m) if m and m~="" then sendRuntime(m) end end,
    runtimeFn = function(m) if m and m~="" then sendRuntime(m) end end,

    onJoin = function(_, full)
      QUIZ.byShort[short(full):lower()] = full
    end,

    onClose = function(lobby)
      wipe(QUIZ.players);   for i,full in ipairs(lobby.players) do QUIZ.players[i]=full end
      wipe(QUIZ.joinedSet); for _,full in ipairs(lobby.players) do QUIZ.joinedSet[full]=true end

      local minP = lobby.minPlayers or 2
      if #QUIZ.players < minP then
        sendRuntime("Not enough players for the quiz.")
        HostRelease()
        HandshakeReset()
        resetQuizState()
        return
      end

      startQuizRun()
    end,

    onCancel = function(_, _why)
      sendRuntime("Quiz lobby cancelled.")
      HostRelease()
      HandshakeReset()
      resetQuizState()
    end,
  })

  -- Single tidy summary line AFTER PsyLobby's intro blurbs
  local poolCount = #(getSelectedQuestions())
  local shownCount = QUIZ._runQCountExplicit and math.min(QUIZ.qcount or poolCount, poolCount) or poolCount
  sendRuntime(("%s — Time Per Question: %ds — Questions: %d"):format(quizName, QUIZ.qtime, shownCount))

  -- Solo convenience: auto-join host so it proceeds immediately
  if opts.solo then
    QUIZ.lobby:AddPlayer(QUIZ.host)
    wipe(QUIZ.joinedSet); for _,full in ipairs(QUIZ.lobby.players) do QUIZ.joinedSet[full]=true end
  end

  -- show an empty scores panel already in lobby (nice preview)
  pushScoresToUI()
end

------------------------------------------------------------
-- Slash: /psyquiz
--   Quick start: /psyquiz                -> lobby 5 players, ALL questions (current quiz)
--   (primary)   /psyquiz [players] [questions]
--   list | use <id|name> | info | score | stop
--   qtime <seconds>      -> set default per-question time
--   gap   <seconds>      -> set quiet pause between questions
--   reveal <seconds>     -> set green reveal hold time before next question
--   solo [questions]     -> solo run (players=1)
------------------------------------------------------------
SLASH_PSYQUIZ1 = "/psyquiz"
SlashCmdList.PSYQUIZ = function(msg)
  msg = trim(msg or "")
  local a1, rest = msg:match("^(%S+)%s*(.*)$")
  a1 = (a1 or ""):lower()

  if msg == "" then
    if QUIZ.active or (QUIZ.lobby and QUIZ.lobby.active) then printLocal("A quiz is already running."); return end
    openQuizLobby({ solo=false, maxPlayers=5, duration=30, qtime=QUIZ.qtime, qcount=nil })
    return
  end

  if a1 == "list" then
    local list = _G.PsyQuiz.GetQuizzes()
    if #list == 0 then printLocal("No quizzes registered.") return end
    printLocal("Available quizzes:")
    for _,q in ipairs(list) do
      printLocal(string.format("  %d) %s — %d questions", q.id, q.name, q.count or 0))
    end
    printLocal("Run: /psyquiz [players] [questions]  (or just /psyquiz for quick start)")
    return
  end

  if a1 == "use" then
    local arg = trim(rest or "")
    local id = _G.PsyQuiz.Select(arg)
    if not id then printLocal("Quiz not found. Try /psyquiz list.") return end
    local e = QUIZ.registry[ QUIZ.byId[id] ]
    printLocal(string.format("Selected: %d) %s (%d questions)", id, e.name, #(e.questions or {})))
    return
  end

  if a1 == "info" or a1 == "menu" then
    local id = ensureSelectedOrDefault()
    if not id then printLocal("No quizzes registered.") return end
    local e = QUIZ.registry[QUIZ.byId[id]]
    printLocal(string.format("Selected quiz: %d) %s — %d questions", id, e.name, #e.questions))
    for i=1, math.min(10, #e.questions) do
      local q = e.questions[i]
      printLocal(string.format("  Q%d: %s", i, q.q or "?"))
    end
    printLocal("Use: /psyquiz [players] [questions]  (or just /psyquiz for quick start)")
    printLocal("      /psyquiz list   — list all quizzes")
    printLocal("      /psyquiz use <id|name> — select quiz")
    printLocal("      /psyquiz score  — show current scores")
    printLocal("      /psyquiz stop   — stop current quiz")
    printLocal("      /psyquiz qtime <sec> — set question time")
    printLocal("      /psyquiz gap <sec>   — set gap between questions")
    printLocal("      /psyquiz reveal <sec> — set reveal hold time before next question")
    printLocal("      /psyquiz solo [questions] — start solo run")
    return
  end

  if a1 == "score" then
    announceScoreboard()
    return
  end

  if a1 == "stop" then
    if (QUIZ.lobby and QUIZ.lobby.active) then QUIZ.lobby:Stop("stopped")
    elseif QUIZ.active then endQuiz("stopped") else printLocal("No quiz running.") end
    return
  end

  if a1 == "qtime" then
    local s = tonumber(rest)
    if not s then printLocal("Usage: /psyquiz qtime <seconds>"); return end
    QUIZ.qtime = math.max(3, math.floor(s))
    printLocal(string.format("Per-question time set to %ds", QUIZ.qtime))
    return
  end

  if a1 == "gap" then
    local s = tonumber(rest)
    if not s then printLocal("Usage: /psyquiz gap <seconds>"); return end
    QUIZ.gap = math.max(0, s)
    printLocal(string.format("Inter-question gap set to %.1fs", QUIZ.gap))
    return
  end

  if a1 == "reveal" then
    local s = tonumber(rest)
    if s == nil then printLocal("Usage: /psyquiz reveal <seconds> (0 = instant)") return end
    QUIZ.reveal = math.max(0, s)
    printLocal(string.format("Reveal hold time set to %.2fs", QUIZ.reveal))
    return
  end

  if a1 == "solo" then
    if QUIZ.active or (QUIZ.lobby and QUIZ.lobby.active) then printLocal("A quiz is already running."); return end
    local qn = tonumber(rest)  -- questions
    local poolCount = #(getSelectedQuestions())
    local qcount = qn and math.max(1, math.min(qn, poolCount)) or poolCount
    openQuizLobby({ solo=true, maxPlayers=1, duration=30, qtime=QUIZ.qtime, qcount=qcount })
    return
  end

  if QUIZ.active or (QUIZ.lobby and QUIZ.lobby.active) then printLocal("A quiz is already running."); return end

  local p1, p2 = msg:match("^(%d+)%s*(%d*)$")
  if not p1 then
    printLocal("Usage: /psyquiz [players] [questions]")
    printLocal("Examples: /psyquiz 5 10   |  /psyquiz 8   (all questions)   |  /psyquiz (quick start)")
    return
  end

  local maxP = math.max(2, math.min(tonumber(p1) or 5, 40))
  local poolCount = #(getSelectedQuestions())
  local qcount = tonumber(p2)
  if qcount then qcount = math.max(1, math.min(qcount, poolCount)) end
  openQuizLobby({ solo=false, maxPlayers=maxP, duration=30, qtime=QUIZ.qtime, qcount=qcount })
end

------------------------------------------------------------
-- Events: accept answers (never guild) + addon messages
------------------------------------------------------------
local EVENTS = {
  "CHAT_MSG_SAY","CHAT_MSG_PARTY","CHAT_MSG_PARTY_LEADER",
  "CHAT_MSG_RAID","CHAT_MSG_RAID_LEADER",
  "CHAT_MSG_INSTANCE_CHAT","CHAT_MSG_INSTANCE_CHAT_LEADER",
  "CHAT_MSG_WHISPER","CHAT_MSG_EMOTE","CHAT_MSG_TEXT_EMOTE",
  "CHAT_MSG_ADDON",
}
for _,ev in ipairs(EVENTS) do f:RegisterEvent(ev) end

f:SetScript("OnEvent", function(_, event, ...)
  if event == "CHAT_MSG_ADDON" then
    local prefix, msg, channel, sender = ...
    -- Host lock messages
    OnHostAddonMsg(prefix, msg, channel, sender)
    -- UI mirror + handshake + score mirror
    NetOnAddonMsg(prefix, msg, channel, sender)
    return
  end

  local msg, author = ...
  onChatMessage(event, msg or "", author or "")
end)
