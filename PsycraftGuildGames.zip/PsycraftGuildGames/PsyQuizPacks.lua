-- PsyQuizPacks.lua
-- Data-only: append quizzes to _G.PsyQuiz_Quizzes. No logic.

_G.PsyQuiz_Quizzes = _G.PsyQuiz_Quizzes or {}

local function Q(n, prompt)
  return string.format("Q%02d : %s", n, prompt)
end

table.insert(_G.PsyQuiz_Quizzes, {
  {
    name = "WoW Lore",
    diff = "Easy",
    qs = {
      { q=Q (  1, "Who is the Warchief of the Horde at the start of WoW Classic?"), choices={"Thrall","Garrosh","Vol'jin","Sylvanas"}, correct=1 },
      { q=Q(  2, "Leader of the Alliance in Classic?"), choices={"Varian","Anduin","Tyrande","Magni"}, correct=1 },
      { q=Q(  3, "The Lich King’s human name?"), choices={"Arthas Menethil","Uther","Bolvar Fordragon","Ner'zhul"}, correct=1 },
      { q=Q(  4, "City of the Forsaken?"), choices={"Undercity","Silvermoon","Orgrimmar","Thunder Bluff"}, correct=1 },
      { q=Q(  5, "Night Elf starting zone?"), choices={"Teldrassil","Azuremyst Isle","Dun Morogh","Elwynn Forest"}, correct=1 },
      { q=Q(  6, "Where is the Dark Portal located?"), choices={"Blasted Lands","Searing Gorge","Silithus","Tanaris"}, correct=1 },
      { q=Q(  7, "Which dragon aspect is the Life-Binder?"), choices={"Nozdormu","Alexstrasza","Ysera","Malygos"}, correct=2 },
      { q=Q(  8, "Capital of the Tauren?"), choices={"Orgrimmar","Thunder Bluff","Silvermoon","Camp Mojache"}, correct=2 },
      { q=Q(  9, "Faction controlling Stormwind?"), choices={"Horde","Alliance","Scourge","Burning Legion"}, correct=2 },
      { q=Q( 10, "Famed hunter in Orgrimmar?"), choices={"Rexxar","Vol'jin","Garrosh","Cairne"}, correct=1 },
      { q=Q( 11, "Race allied with Gnomes?"), choices={"Dwarves","Humans","Night Elves","Worgen"}, correct=1 },
      { q=Q( 12, "Which Titan created Azeroth's world-soul?"), choices={"Sargeras","Eonar","Aman'Thul","None"}, correct=4 },
      { q=Q( 13, "Zone where Zul'Gurub is located?"), choices={"Stranglethorn Vale","Tirisfal","Duskwood","Swamp of Sorrows"}, correct=1 },
      { q=Q( 14, "Home city of the Gnomes?"), choices={"Ironforge","Gnomeregan","Stormwind","Gilneas"}, correct=2 },
      { q=Q( 15, "Who betrays Garithos in Warcraft III?"), choices={"Kael'thas","Sylvanas","Jaina","Illidan"}, correct=1 },
    }
  },
  {
    name = "WoW Raids & Dungeons",
    diff = "Medium",
    qs = {
      { q=Q(  1, "Final boss of Molten Core?"), choices={"Geddon","Majordomo","Ragnaros","Lucifron"}, correct=3 },
      { q=Q(  2, "Blackwing Lair is in which mountain?"), choices={"Blackrock","Redridge","Storm Peaks","Burning Steppes"}, correct=1 },
      { q=Q(  3, "AQ20 entrance zone?"), choices={"Tanaris","Silithus","Uldum","Feralas"}, correct=2 },
      { q=Q(  4, "AQ40 boss with mind control?"), choices={"Ouro","C'Thun","Twin Emperors","Viscidus"}, correct=3 },
      { q=Q(  5, "Scarlet Monastery is in which zone?"), choices={"Tirisfal Glades","Eastern Plaguelands","Silverpine","Western Plaguelands"}, correct=1 },
      { q=Q(  6, "Stratholme undead side final boss?"), choices={"Baron Rivendare","Balnazzar","Ramstein","Tirion"}, correct=1 },
      { q=Q(  7, "Karazhan is in which zone?"), choices={"Deadwind Pass","Blasted Lands","Duskwood","Swamp of Sorrows"}, correct=1 },
      { q=Q(  8, "Boss before Nefarian in BWL?"), choices={"Firemaw","Chromaggus","Vaelastrasz","Ebonroc"}, correct=2 },
      { q=Q(  9, "Instance in Dustwallow Marsh?"), choices={"Zul'Farrak","Dire Maul","Maraudon","Onyxia's Lair"}, correct=4 },
      { q=Q( 10, "Ulduar keeper with a cat mount drop?"), choices={"Hodir","Thorim","Freya","Mimiron"}, correct=2 },
      { q=Q( 11, "Black Temple location?"), choices={"Shadowmoon Valley","Hellfire Peninsula","Zangarmarsh","Netherstorm"}, correct=1 },
      { q=Q( 12, "First boss of ICC?"), choices={"Marrowgar","Putricide","Festergut","Saurfang"}, correct=1 },
      { q=Q( 13, "Dungeon with Deadmines boss Edwin?"), choices={"Westfall","Elwynn","Redridge","Stormwind"}, correct=1 },
      { q=Q( 14, "Shadowfang Keep final boss?"), choices={"Arugal","Nandos","Kelris","Shadowfang"}, correct=1 },
      { q=Q( 15, "Sunwell Plateau is on which island?"), choices={"Azuremyst","Quel'Danas","Keel","Isle of Thunder"}, correct=2 },
    }
  },
  {
    name = "WoW Professions",
    diff = "Easy",
    qs = {
      { q=Q(  1, "Primary metal in Elwynn Forest?"), choices={"Copper","Tin","Iron","Silver"}, correct=1 },
      { q=Q(  2, "Fishing skill used to catch Deviate Fish?"), choices={"100","225","1","150"}, correct=3 },
      { q=Q(  3, "Trainer for Herbalism is marked by what icon?"), choices={"Herb","Flower","Leaf","Green Dot"}, correct=2 },
      { q=Q(  4, "Highest classic cooking rank?"), choices={"Expert","Artisan","Journeyman","Master"}, correct=2 },
      { q=Q(  5, "Enchanting material from dust?"), choices={"Essence","Shard","Rod","Dust"}, correct=1 },
      { q=Q(  6, "Specialization in Leatherworking?"), choices={"Dragonscale","Tribal","Elemental","All of these"}, correct=4 },
      { q=Q(  7, "Where to mine Thorium in Classic?"), choices={"Un'Goro Crater","Durotar","Westfall","Teldrassil"}, correct=1 },
      { q=Q(  8, "Profession that makes flasks?"), choices={"Alchemy","Engineering","Blacksmithing","Cooking"}, correct=1 },
      { q=Q(  9, "Crafted bag by Tailoring?"), choices={"Backpack","Satchel","Runecloth Bag","Trapper's Pack"}, correct=3 },
      { q=Q( 10, "Fishing daily quest giver in Dalaran?"), choices={"Marcia Chase","Old Man Barlo","Nat Pagle","Ben of the Booming Voice"}, correct=1 },
      { q=Q( 11, "Inscription makes what items?"), choices={"Potions","Scrolls","Trinkets","Bags"}, correct=2 },
      { q=Q( 12, "Smelting skill comes from which profession?"), choices={"Blacksmithing","Mining","Engineering","Alchemy"}, correct=2 },
      { q=Q( 13, "First aid max skill in Classic?"), choices={"150","300","225","375"}, correct=2 },
      { q=Q( 14, "Tailors make which cloth armor types?"), choices={"Cloth","Leather","Mail","Plate"}, correct=1 },
      { q=Q( 15, "Engineering item to resurrect players?"), choices={"Jumper Cables","Defibrillator","Life Rod","Tinker Tool"}, correct=1 },
    }
  },
  {
    name = "WoW Zones & Geography",
    diff = "Medium",
    qs = {
      { q=Q(  1, "Zone between Westfall and Duskwood?"), choices={"Elwynn Forest","Redridge","Deadwind Pass","Stranglethorn"}, correct=1 },
      { q=Q(  2, "Home of the Troll race?"), choices={"Echo Isles","Sen'jin Village","Stranglethorn","Zul'Drak"}, correct=2 },
      { q=Q(  3, "Which zone contains Blackrock Mountain?"), choices={"Burning Steppes","Searing Gorge","Both","Neither"}, correct=3 },
      { q=Q(  4, "Tanaris is part of which continent?"), choices={"Kalimdor","Eastern Kingdoms","Northrend","Pandaria"}, correct=1 },
      { q=Q(  5, "Winterspring connects to which zone via tunnel?"), choices={"Felwood","Azshara","Moonglade","Darkshore"}, correct=1 },
      { q=Q(  6, "Blood Elf starting area?"), choices={"Silvermoon","Eversong Woods","Ghostlands","Sunstrider Isle"}, correct=2 },
      { q=Q(  7, "Where is Scarlet Monastery?"), choices={"Tirisfal Glades","Silverpine","Plaguelands","Hinterlands"}, correct=1 },
      { q=Q(  8, "Zone with Gadgetzan?"), choices={"Tanaris","Un'Goro","Thousand Needles","Badlands"}, correct=1 },
      { q=Q(  9, "Home of the Wildhammer Dwarves?"), choices={"Loch Modan","Twilight Highlands","The Hinterlands","Wetlands"}, correct=3 },
      { q=Q( 10, "Zone before entering Uldum from the north?"), choices={"Tanaris","Thousand Needles","Silithus","Un'Goro"}, correct=3 },
      { q=Q( 11, "Shattrath City is in which zone?"), choices={"Terokkar Forest","Nagrand","Netherstorm","Shadowmoon"}, correct=1 },
      { q=Q( 12, "Northrend starting zones?"), choices={"Borean Tundra & Howling Fjord","Dragonblight & Grizzly Hills","Zul'Drak & Sholazar","Icecrown & Storm Peaks"}, correct=1 },
      { q=Q( 13, "Zone with the city of Suramar?"), choices={"Azsuna","Val'sharah","Suramar","Highmountain"}, correct=3 },
      { q=Q( 14, "Where is the Argent Tournament?"), choices={"Icecrown","Storm Peaks","Crystalsong","Dragonblight"}, correct=1 },
      { q=Q( 15, "Area surrounding Karazhan?"), choices={"Deadwind Pass","Duskwood","Redridge","Swamp of Sorrows"}, correct=1 },
    }
  },
  
  {
    name = "WoW Mechanics",
    diff = "Hard",
    qs = {
      { q=Q(  1, "Max player level in Burning Crusade Classic?"), choices={"60","70","80","85"}, correct=2 },
      { q=Q(  2, "Max skill level for a profession in Wrath?"), choices={"375","400","425","450"}, correct=4 },
      { q=Q(  3, "Hit rating reduces chance to miss by?"), choices={"1% per 15.77 rating","1% per 32.79 rating","1% per 25 rating","1% per 50 rating"}, correct=2 },
      { q=Q(  4, "Global cooldown in seconds for most abilities?"), choices={"1.0","1.5","2.0","2.5"}, correct=2 },
      { q=Q(  5, "Expertise reduces chance to be…"), choices={"Dodged & Parried","Crit","Hit","Blocked"}, correct=1 },
      { q=Q(  6, "Resilience reduces…"), choices={"Damage from crits","Armor Penetration","Spell Hit","Mana Cost"}, correct=1 },
      { q=Q(  7, "Defense skill needed to be uncrittable in Classic?"), choices={"440","450","490","400"}, correct=3 },
      { q=Q(  8, "Armor cap % reduction vs bosses?"), choices={"75%","50%","70%","35%"}, correct=3 },
      { q=Q(  9, "Spell hit cap % for casters vs bosses in Classic?"), choices={"12%","16%","8%","10%"}, correct=2 },
      { q=Q( 10, "Max arena team size in TBC?"), choices={"2","3","5","All of these"}, correct=4 },
      { q=Q( 11, "Block value reduces…"), choices={"Attack speed","Spell damage","Physical damage","Crit chance"}, correct=3 },
      { q=Q( 12, "Spirit affects…"), choices={"Mana regen","Hit chance","Crit chance","Armor"}, correct=1 },
      { q=Q( 13, "Base player movement speed?"), choices={"100%","115%","120%","90%"}, correct=1 },
      { q=Q( 14, "Which stat increases attack speed?"), choices={"Agility","Haste","Strength","Crit"}, correct=2 },
      { q=Q( 15, "Hard cap for Expertise?"), choices={"26","56","16","32"}, correct=1 },
    }
  },
{
    name = "League of Legends - Maps & Lore",
    diff = "Medium",
    qs = {
      { q=Q(  1, "What is the main map used for standard 5v5 games?"), choices={"Summoner's Rift","Howling Abyss","Twisted Treeline","Crystal Scar"}, correct=1 },
      { q=Q(  2, "Which map is used for ARAM mode?"), choices={"Twisted Treeline","Summoner's Rift","Howling Abyss","Butcher's Bridge"}, correct=3 },
      { q=Q(  3, "Where does Ashe originate from?"), choices={"Demacia","Noxus","Freljord","Ionia"}, correct=3 },
      { q=Q(  4, "What is the home region of Yasuo?"), choices={"Ionia","Demacia","Shurima","Bilgewater"}, correct=1 },
      { q=Q(  5, "Which region is ruled by Jarvan IV?"), choices={"Noxus","Demacia","Piltover","Zaun"}, correct=2 },
      { q=Q(  6, "What region is home to champions like Zilean and Janna?"), choices={"Piltover","Zaun","Ixtal","Runeterra's Eastern Coast"}, correct=4 },
      { q=Q(  7, "Which desert empire is home to Azir?"), choices={"Shurima","Ixtal","Bandle City","Zaun"}, correct=1 },
      { q=Q(  8, "Bilgewater is best known for what?"), choices={"Pirates and Sea Trade","Desert Kingdom","High Magic","Ancient Ruins"}, correct=1 },
      { q=Q(  9, "Where is the Shadow Isles located?"), choices={"Off the coast of Demacia","West of Ionia","South of Shurima","North of Piltover"}, correct=1 },
      { q=Q( 10, "Which champions are associated with the Shadow Isles?"), choices={"Thresh & Hecarim","Garen & Lux","Jinx & Vi","Yasuo & Yone"}, correct=1 },
      { q=Q( 11, "What is the capital of Piltover known for?"), choices={"Pirate Havens","Technology and Invention","Magic Academies","Military Might"}, correct=2 },
      { q=Q( 12, "Ixtal is famous for its mastery of which element?"), choices={"Fire","Nature","Metal","Darkness"}, correct=2 },
      { q=Q( 13, "Mount Targon is home to which celestial aspect?"), choices={"Aspect of the Sun","Aspect of the Moon","Aspect of the Void","Aspect of the Sea"}, correct=1 },
      { q=Q( 14, "Which faction is Swain the leader of?"), choices={"Demacia","Noxus","Freljord","Zaun"}, correct=2 },
      { q=Q( 15, "What is the magical city at the heart of Ionia?"), choices={"Ixaocan","Navori","Vastaya","Shurima City"}, correct=2 },
    }
  },
{
    name = "LoL Abilities (Ultimate Hard)",
    diff = "Hard",
    qs = {
      { q=Q(  1, "Which champion’s ultimate is 'Chronobreak'?"), choices={"Ekko","Zilean","Kassadin","Fizz"}, correct=1 },

      { q=Q(  2, "Who casts the ultimate 'World Ender'?"),choices={"Aatrox","Mordekaiser","Nocturne","Yone"}, correct=1 },

      { q=Q(  3, "Which champion’s ultimate is 'Hemoplague'?"),
        choices={"Swain","Vladimir","Varus","Cassiopeia"}, correct=2 },

      { q=Q(  4, "Who uses the ultimate 'Subjugate'?"),
        choices={"Trundle","Urgot","Nasus","Sejuani"}, correct=1 },

      { q=Q(  5, "Which ultimate is 'Featherstorm'?"),
        choices={"Xayah","Quinn","Rakan","Kai'Sa"}, correct=1 },

      { q=Q(  6, "Whose ultimate is 'Rite of the Arcane'?"),
        choices={"Vel'Koz","Xerath","Ziggs","Ryze"}, correct=2 },

      { q=Q(  7, "Which champion casts 'Frozen Tomb'?"),
        choices={"Lissandra","Anivia","Ashe","Sejuani"}, correct=1 },

      { q=Q(  8, "Who uses the ultimate 'Stranglethorns'?"),
        choices={"Zyra","Maokai","Ivern","Neeko"}, correct=1 },

      { q=Q(  9, "Which champion’s ultimate is 'Unstoppable Onslaught'?"),
        choices={"Sion","Rammus","Hecarim","Malphite"}, correct=1 },

      { q=Q( 10, "Who casts the ultimate 'Cataclysm'?"),
        choices={"Jarvan IV","Riven","Renekton","Wukong"}, correct=1 },

      { q=Q( 11, "Which champion’s ultimate is 'Let’s Bounce!'?"),
        choices={"Zac","Gragas","Amumu","Singed"}, correct=1 },

      { q=Q( 12, "Whose ultimate is 'Requiem'?"),
        choices={"Malzahar","Karthus","Kassadin","Vel'Koz"}, correct=2 },

      { q=Q( 13, "Which champion uses the ultimate 'Monsoon'?"),
        choices={"Nami","Janna","Sona","Soraka"}, correct=2 },

      { q=Q( 14, "Who casts the ultimate 'Feast'?"),
        choices={"Cho'Gath","Kha'Zix","Tahm Kench","Nunu & Willump"}, correct=1 },

      { q=Q( 15, "Which champion’s ultimate is 'Collateral Damage'?"),
        choices={"Graves","Caitlyn","Jhin","Miss Fortune"}, correct=1 },

      { q=Q( 16, "Whose ultimate is 'Spirit Rush'?"),
        choices={"Ahri","Aurelion Sol","Syndra","LeBlanc"}, correct=1 },

      { q=Q( 17, "Which champion casts 'Call of the Forge God'?"),
        choices={"Sejuani","Ornn","Volibear","Braum"}, correct=2 },

      { q=Q( 18, "Who uses the ultimate 'Chronoshift'?"),
        choices={"Ekko","Zilean","Orianna","Twisted Fate"}, correct=2 },

      { q=Q( 19, "Which champion’s ultimate is 'Slicing Maelstrom'?"),
        choices={"Kennen","Katarina","Kayn","Kennen & Rhaast"}, correct=1 },

      { q=Q( 20, "Whose ultimate is 'Chain of Corruption'?"),
        choices={"Varus","Vayne","Viktor","Veigar"}, correct=1 },
    }
  },
  {
    name = "LoL Abilities + Lore (Ultimate Hard)",
    diff = "Hard",
    qs = {
      -- 1 (correct = 2)
      { q=Q(  1, "Which champion’s ultimate is 'Hallucinate'?"),
        choices={"Nocturne","Shaco","LeBlanc","Fiddlesticks"}, correct=2 },

      -- 2 (correct = 4)
      { q=Q(  2, "Who is the Ruined King?"),
        choices={"Kalista","Hecarim","Thresh","Viego"}, correct=4 },

      -- 3 (correct = 1)
      { q=Q(  3, "Who casts 'Scatter the Weak' (E)?"),
        choices={"Syndra","Orianna","Zoe","Lux"}, correct=1 },

      -- 4 (correct = 3)
      { q=Q(  4, "Which champion’s ultimate is 'Lamb's Respite'?"),
        choices={"Ivern","Ashe","Kindred","Nunu & Willump"}, correct=3 },

      -- 5 (correct = 2)
      { q=Q(  5, "Who casts 'Emperor's Divide' (R)?"),
        choices={"Xerath","Azir","Taliyah","Renekton"}, correct=2 },

      -- 6 (correct = 1)
      { q=Q(  6, "Which champion creates 'Event Horizon' (E)?"),
        choices={"Veigar","Viktor","Xerath","Malzahar"}, correct=1 },

      -- 7 (correct = 4)
      { q=Q(  7, "Sejuani is Warmother of which tribe?"),
        choices={"Avarosan","Freljordian Guard","Frostguard","Winter's Claw"}, correct=4 },

      -- 8 (correct = 3)
      { q=Q(  8, "Which champion’s ultimate is 'Hijack'?"),
        choices={"Neeko","Sylvia","Sylas","Kayle"}, correct=3 },

      -- 9 (correct = 2)
      { q=Q(  9, "Who uses 'World Ender' (R)?"),
        choices={"Yone","Aatrox","Mordekaiser","Riven"}, correct=2 },

      -- 10 (correct = 1)
      { q=Q(  10, "Zed leads which organization in Ionia?"),
        choices={"Order of Shadow","Kinkou Order","Navori Brotherhood","Irelian Guard"}, correct=1 },

      -- 11 (correct = 3)
      { q=Q(  11, "Kegan Rodhe became which champion?"),
        choices={"Brand's Master","Ryze's Rival","Brand","Xerath"}, correct=3 },

      -- 12 (correct = 4)
      { q=Q(  12, "Which champion’s ultimate is 'Realm of Death'?"),
        choices={"Yorick","Kayn","Sion","Mordekaiser"}, correct=4 },

      -- 13 (correct = 2)
      { q=Q(  13, "Which Targonian Aspect does Leona embody?"),
        choices={"The Moon","The Sun","The Protector","The Warrior"}, correct=2 },

      -- 14 (correct = 3)
      { q=Q(  14, "Which champion belongs to the Crownguard family of Demacia?"),
        choices={"Fiora","Jarvan IV","Lux","Garen"}, correct=3 },

      -- 15 (correct = 1)
      { q=Q(  15, "Which champion’s ultimate is 'Paranoia'?"),
        choices={"Nocturne","Shen","Hecarim","Rengar"}, correct=1 },

      -- 16 (correct = 4)
      { q=Q(  16, "Who uses 'Five-Point Strike' (Q)?"),
        choices={"Katarina","Kennen","Irelia","Akali"}, correct=4 },

      -- 17 (correct = 2)
      { q=Q(  17, "Who secretly leads the Frostguard?"),
        choices={"Anivia","Lissandra","Ashe","Sejuani"}, correct=2 },

      -- 18 (correct = 3)
      { q=Q(  18, "Who is the Grand General of Noxus (current canon)?"),
        choices={"Darius","Katarina","Swain","LeBlanc"}, correct=3 },

      -- 19 (correct = 4)
      { q=Q(  19, "Which champion casts 'Call of the Forge God' (R)?"),
        choices={"Braum","Sejuani","Volibear","Ornn"}, correct=4 },

      -- 20 (correct = 1)
      { q=Q(  20, "Which champion’s passive is 'Gift of the Drowned Ones'?"),
        choices={"Pyke","Nautilus","Fizz","Illaoi"}, correct=1 },
    }
  },
  {
    name = "World Geography 1",
    diff = "Hard",
qs = {
  { q=Q(  1, "Capital of Australia?"), choices={"Sydney","Melbourne","Canberra","Perth"}, correct=3 },
  { q=Q(  2, "Largest desert in the world by area?"), choices={"Antarctic Desert","Sahara","Arabian","Gobi"}, correct=1 },
  { q=Q(  3, "Machu Picchu is in which country?"), choices={"Bolivia","Ecuador","Chile","Peru"}, correct=4 },
  { q=Q(  4, "Which river flows through Paris?"), choices={"Thames","Seine","Danube","Rhine"}, correct=2 },
  { q=Q(  5, "Which continent has the most countries?"), choices={"Asia","Africa","Europe","South America"}, correct=2 },
  { q=Q(  6, "Mount Kilimanjaro is in which country?"), choices={"Kenya","Uganda","Tanzania","Ethiopia"}, correct=3 },
  { q=Q(  7, "Smallest country in the world by area?"), choices={"Vatican City","Monaco","Nauru","San Marino"}, correct=1 },
  { q=Q(  8, "Which sea separates Europe and Africa?"), choices={"Baltic Sea","Black Sea","Adriatic Sea","Mediterranean Sea"}, correct=4 },
  { q=Q(  9, "Capital of Canada?"), choices={"Toronto","Ottawa","Vancouver","Montreal"}, correct=2 },
  { q=Q( 10, "Which U.S. state has the Grand Canyon?"), choices={"Utah","New Mexico","Arizona","Nevada"}, correct=3 },
  { q=Q( 11, "Largest island in the world?"), choices={"Greenland","New Guinea","Borneo","Madagascar"}, correct=1 },
  { q=Q( 12, "Which line is at 0° longitude?"), choices={"Tropic of Cancer","Equator","Arctic Circle","Prime Meridian"}, correct=4 },
  { q=Q( 13, "Istanbul straddles which two continents?"), choices={"Asia & Africa","Europe & Africa","Europe & Asia","Asia & Oceania"}, correct=3 },
  { q=Q( 14, "Lake Baikal is primarily in which country?"), choices={"Mongolia","Russia","Kazakhstan","China"}, correct=2 },
  { q=Q( 15, "Which country has the most natural lakes?"), choices={"Canada","Finland","United States","Russia"}, correct=1 },
}
  },
{
    name = "League of Legends - Hard Mode",
    diff = "Hard",
    qs = {
        { q=Q(  1, "Which champion was the first to be released after the game's beta?"), choices={"Udyr","Singed","Mordekaiser","Ezreal"}, correct=4 },
        { q=Q(  2, "Which region is home to the champion Ivern?"), choices={"Ionia","Demacia","Freljord","Ixtal"}, correct=4 },
        { q=Q(  3, "Which champion’s ultimate is called 'World Ender'?"), choices={"Aatrox","Mordekaiser","Pantheon","Yone"}, correct=1 },
        { q=Q(  4, "Which champion has the highest base movement speed in the game (without abilities)?"), choices={"Master Yi","Cassiopeia","Rammus","Hecarim"}, correct=2 },
        { q=Q(  5, "Who was the first champion to have their ultimate ability available at level 1 in some game modes?"), choices={"Elise","Kled","Kalista","Ryze"}, correct=2 },
        { q=Q(  6, "Which item was removed and replaced with Sunfire Aegis in the Mythic rework?"), choices={"Sunfire Cape","Warmog’s Armor","Dead Man’s Plate","Randuin’s Omen"}, correct=1 },
        { q=Q(  7, "What is the maximum critical strike chance possible in League without special effects?"), choices={"80%","100%","95%","90%"}, correct=2 },
        { q=Q(  8, "Which champion has a passive that allows them to store two charges of their ultimate ability?"), choices={"Rengar","Katarina","Jhin","Corki"}, correct=1 },
        { q=Q(  9, "Before her rework, which champion had an ability called 'Purge'?"), choices={"Urgot","Graves","Gangplank","Miss Fortune"}, correct=1 },
        { q=Q( 10, "Which champion is canonically the oldest by age?"), choices={"Ornn","Bard","Aurelion Sol","Kindred"}, correct=3 },
        { q=Q( 11, "Which rune grants bonus movement speed and adaptive force after using a summoner spell?"), choices={"Nimbus Cloak","Waterwalking","Celerity","Phase Rush"}, correct=1 },
        { q=Q( 12, "Which champion’s ultimate can be recast within a short window to reposition its effect?"), choices={"Miss Fortune","Vel'Koz","Viktor","Vladimir"}, correct=2 },
        { q=Q( 13, "What is the name of the item that replaced Atma’s Impaler in the store?"), choices={"Serylda’s Grudge","Titanic Hydra","Sterak’s Gage","Dead Man’s Plate"}, correct=4 },
        { q=Q( 14, "Which champion says 'Death is like the wind, always by my side'?"), choices={"Zed","Yone","Yasuo","Jhin"}, correct=3 },
        { q=Q( 15, "Which champion can place the most wards at once without items or runes?"), choices={"Teemo","Shaco","Maokai","Ivern"}, correct=3 },
    }
},
{
    name = "League of Legends - Hard Mode 2",
    diff = "Hard",
    qs = {
        { q=Q(  1, "Which champion’s passive is called 'Harmless Trickster'?"), choices={"Neeko","Fizz","Shaco","Zoe"}, correct=2 },
        { q=Q(  2, "Which lane did Twisted Fate primarily play in competitive Season 1?"), choices={"Bot Lane","Mid Lane","Top Lane","Jungle"}, correct=2 },
        { q=Q(  3, "Who is the biological father of Kai’Sa?"), choices={"Kassadin","Malzahar","Nocturne","Kennen"}, correct=1 },
        { q=Q(  4, "Which champion has the lowest base attack range in the game?"), choices={"Rakan","Samira","Yuumi","Rell"}, correct=4 },
        { q=Q(  5, "Which champion was released alongside the 'Spirit Blossom' event?"), choices={"Sett","Yone","Lillia","Aphelios"}, correct=3 },
        { q=Q(  6, "Which buff does Baron Nashor provide besides AP and AD bonus?"), choices={"Movement Speed","Empowered Recall","Health Regen","Armor Penetration"}, correct=2 },
        { q=Q(  7, "Which champion was originally called 'Priscilla the Spider Queen' in development?"), choices={"Elise","Camille","Illaoi","Neeko"}, correct=1 },
        { q=Q(  8, "Which champion is permanently immune to slows while moving toward enemies?"), choices={"Singed","Rammus","Olaf","Hecarim"}, correct=3 },
        { q=Q(  9, "Which item’s active is 'Frost Nova'?"), choices={"Randuin’s Omen","Twin Shadows","Everfrost","Frozen Heart"}, correct=1 },
        { q=Q( 10, "Which champion was removed from competitive play the longest due to balance issues?"), choices={"Ryze","Kalista","Azir","Aphelios"}, correct=2 },
        { q=Q( 11, "What’s the max stacks Bloodthirster’s shield can reach?"), choices={"300","350","400","450"}, correct=3 },
        { q=Q( 12, "Which champion’s voice line says 'Justice takes wing'?"), choices={"Fiora","Kayle","Quinn","Lux"}, correct=2 },
        { q=Q( 13, "Which rune causes enemies to take more damage after being immobilized?"), choices={"Electrocute","Cheap Shot","Aftershock","Font of Life"}, correct=2 },
        { q=Q( 14, "Which champion’s dance is a reference to Michael Jackson’s 'Smooth Criminal'?"), choices={"Twisted Fate","Lucian","Ekko","Jhin"}, correct=1 },
        { q=Q( 15, "What is the name of Yasuo’s half-brother?"), choices={"Yone","Shen","Zed","Master Yi"}, correct=1 },
    }
},
{
    name = "League of Legends - Hard Mode 3",
    diff = "Hard",
    qs = {
        { q=Q(  1, "Which champion has the ability 'Chronobreak'?"), choices={"Zilean","Ekko","Twisted Fate","Jhin"}, correct=2 },
        { q=Q(  2, "What is Teemo’s movement speed with Move Quick (active) at rank 5 without items?"), choices={"425","435","445","455"}, correct=3 },
        { q=Q(  3, "Which champion’s lore involves being resurrected through a deal with the Mist?"), choices={"Hecarim","Thresh","Viego","Kalista"}, correct=4 },
        { q=Q(  4, "What is the maximum number of tentacles Illaoi can have active at once without items?"), choices={"4","5","6","7"}, correct=3 },
        { q=Q(  5, "Which champion’s ultimate has the longest cooldown at rank 1?"), choices={"Ezreal","Karthus","Anivia","Gangplank"}, correct=2 },
        { q=Q(  6, "Which item gives both attack speed and life steal?"), choices={"Bloodthirster","Blade of the Ruined King","Kraken Slayer","Immortal Shieldbow"}, correct=2 },
        { q=Q(  7, "Which champion’s real name is Shauna Vayne?"), choices={"Caitlyn","Vi","Vayne","Rell"}, correct=3 },
        { q=Q(  8, "Which champion was the first to be designed with a mini-game mechanic built into their kit?"), choices={"Bard","Tahm Kench","Kindred","Jhin"}, correct=1 },
        { q=Q(  9, "Which summoner spell was removed from the game in Season 1?"), choices={"Revive","Promote","Surge","Clarity"}, correct=1 },
        { q=Q( 10, "Which champion’s weapon is called 'Moonstone'?"), choices={"Aphelios","Diana","Leona","Soraka"}, correct=2 },
        { q=Q( 11, "Which rune grants a shield and movement speed after 2.5 seconds in combat?"), choices={"Phase Rush","Fleet Footwork","Guardian","Aftershock"}, correct=3 },
        { q=Q( 12, "What is the cooldown of Smite at rank 1?"), choices={"75s","90s","100s","60s"}, correct=2 },
        { q=Q( 13, "Which champion’s original title was 'the Fist of Shadow'?"), choices={"Shen","Akali","Lee Sin","Zed"}, correct=2 },
        { q=Q( 14, "Which champion’s passive is called 'Pix, Faerie Companion'?"), choices={"Karma","Lulu","Soraka","Janna"}, correct=2 },
        { q=Q( 15, "Which champion can store up to 4 ammo in their ultimate?"), choices={"Jhin","Caitlyn","Miss Fortune","Lucian"}, correct=1 },
    }
},
{
    name = "Marvel Rivals - Easy Mode",
    diff = "Easy",
    qs = {
        { q=Q(  1, "Which hero is known as the 'First Avenger'?"), choices={"Iron Man","Captain America","Thor","Hulk"}, correct=2 },
        { q=Q(  2, "Which character is the God of Thunder?"), choices={"Loki","Thor","Odin","Beta Ray Bill"}, correct=2 },
        { q=Q(  3, "Which hero has a metal arm and is known as the Winter Soldier?"), choices={"Bucky Barnes","Sam Wilson","Clint Barton","Nick Fury"}, correct=1 },
        { q=Q(  4, "Which Marvel team includes Star-Lord and Groot?"), choices={"Avengers","Guardians of the Galaxy","X-Men","Fantastic Four"}, correct=2 },
        { q=Q(  5, "Who wears a red and gold armored suit?"), choices={"Iron Man","War Machine","Ant-Man","Spider-Man"}, correct=1 },
        { q=Q(  6, "Which hero uses a shield made of vibranium?"), choices={"Captain America","Black Panther","Hawkeye","Falcon"}, correct=1 },
        { q=Q(  7, "Who is Peter Parker’s alter ego?"), choices={"Spider-Man","Venom","Deadpool","Nightcrawler"}, correct=1 },
        { q=Q(  8, "Which character can shrink and grow using Pym Particles?"), choices={"Ant-Man","Wasp","Hank Pym","All of the above"}, correct=4 },
        { q=Q(  9, "Which hero turns green and gains super strength when angry?"), choices={"She-Hulk","Hulk","Abomination","The Thing"}, correct=2 },
        { q=Q( 10, "Which villain is known for collecting Infinity Stones?"), choices={"Thanos","Ultron","Loki","Red Skull"}, correct=1 },
        { q=Q( 11, "Which hero uses a bow and arrows?"), choices={"Hawkeye","Green Arrow","Black Widow","Winter Soldier"}, correct=1 },
        { q=Q( 12, "Who is the King of Wakanda?"), choices={"M'Baku","Killmonger","Black Panther","Storm"}, correct=3 },
        { q=Q( 13, "Which hero is a master of magic and the Mystic Arts?"), choices={"Scarlet Witch","Doctor Strange","Loki","Ancient One"}, correct=2 },
        { q=Q( 14, "Which Marvel character is a raccoon with advanced tech skills?"), choices={"Rocket","Howard the Duck","Cosmo","Lockjaw"}, correct=1 },
        { q=Q( 15, "Who leads the X-Men?"), choices={"Cyclops","Wolverine","Professor X","Storm"}, correct=3 },
    }
},
{
    name = "Makeup Brands",
    diff = "Easy",
    qs = {
        { q=Q(  1, "Which brand is famous for its Naked eyeshadow palettes?"), choices={"Urban Decay","MAC","Too Faced","NARS"}, correct=1 },
        { q=Q(  2, "Fenty Beauty was founded by which singer?"), choices={"Beyoncé","Rihanna","Adele","Lady Gaga"}, correct=2 },
        { q=Q(  3, "Which brand is known for its 'Better Than Sex' mascara?"), choices={"Benefit","Too Faced","Tarte","Maybelline"}, correct=2 },
        { q=Q(  4, "Which drugstore brand makes the 'Fit Me' foundation line?"), choices={"L'Oréal","CoverGirl","Maybelline","Revlon"}, correct=3 },
        { q=Q(  5, "Anastasia Beverly Hills is best known for which product type?"), choices={"Lipsticks","Eyebrow products","Blushes","Foundations"}, correct=2 },
        { q=Q(  6, "Which brand sells the 'Shape Tape' concealer?"), choices={"NYX","Tarte","Huda Beauty","Clinique"}, correct=2 },
        { q=Q(  7, "Kylie Jenner launched which makeup brand?"), choices={"KKW Beauty","Kylie Cosmetics","Rare Beauty","Fenty Beauty"}, correct=2 },
        { q=Q(  8, "Which luxury brand is known for the 'Rouge Pur Couture' lipstick line?"), choices={"Chanel","Dior","YSL Beauty","Givenchy"}, correct=3 },
        { q=Q(  9, "Which brand has the slogan 'Maybe she’s born with it'?"), choices={"L'Oréal","Maybelline","Revlon","CoverGirl"}, correct=2 },
        { q=Q( 10, "Which celebrity founded Rare Beauty?"), choices={"Selena Gomez","Ariana Grande","Hailey Bieber","Miley Cyrus"}, correct=1 },
        { q=Q( 11, "Which brand is famous for its 'Double Wear' foundation?"), choices={"Estée Lauder","Lancome","MAC","Clinique"}, correct=1 },
        { q=Q( 12, "Which Korean beauty brand is known for cushion foundations?"), choices={"Innisfree","Etude House","Sulwhasoo","All of the above"}, correct=4 },
        { q=Q( 13, "Huda Beauty was founded in which country?"), choices={"USA","UAE","UK","France"}, correct=2 },
        { q=Q( 14, "Which brand makes the 'Lash Sensational' mascara?"), choices={"L'Oréal","Rimmel","Maybelline","Essence"}, correct=3 },
        { q=Q( 15, "Which luxury brand produces 'Diorshow' mascara?"), choices={"Chanel","Dior","Gucci","Givenchy"}, correct=2 },
    }
},






})
